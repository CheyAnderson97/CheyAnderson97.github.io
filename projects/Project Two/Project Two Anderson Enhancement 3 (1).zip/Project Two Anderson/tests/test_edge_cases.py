# **************************************
# CS 499 - Enhancement 3
# Original - CS 340 Project 2
# Author - Cheyenne Anderson
# Date - October 2, 2026
# **************************************

#Imports
import os
import sys
import pytest

# Edge case tests for sanitizeInputDict
#These verify truncation, nested operator stripping, list handling, and dotted-key rejection.
sys.path.insert(0, os.path.abspath("."))
from SecureAnimalShelterDAO import SecureAnimalShelterDAO

# Test for long string truncation
def test_long_string_truncation():
	long_name = "a" * (SecureAnimalShelterDAO.MAX_STRING_LEN + 50)
	clean = SecureAnimalShelterDAO.sanitizeInputDict({"name": long_name})
	assert len(clean["name"]) == SecureAnimalShelterDAO.MAX_STRING_LEN

#Test that non-dict input raises ValueError
def test_non_dict_input_raises():
	with pytest.raises(ValueError):
		SecureAnimalShelterDAO.sanitizeInputDict(["not", "a", "dict"])


#Test that nested dicts are sanitized
def test_rejects_nested_dict():
	# Nested dict could be used to pass operators 
	# Nested operator keys should be stripped out, leaving an empty dict for that field
	clean = SecureAnimalShelterDAO.sanitizeInputDict({"age": {"$gt": 2}})
	assert "age" in clean
	assert clean["age"] == {}


#Test that lists of scalars are allowed
def test_lists_of_scalars_allowed():
	clean = SecureAnimalShelterDAO.sanitizeInputDict({"name": ["a", "b"]})
	assert isinstance(clean["name"], list)
	assert clean["name"] == ["a", "b"]


#Test that numeric types are allowed	
def test_numeric_types_allowed():
	clean = SecureAnimalShelterDAO.sanitizeInputDict({"age": 5, "name": "Fido"})
	assert clean["age"] == 5
	assert clean["name"] == "Fido"

#Test that dotted keys are rejected
def test_rejects_dotted_and_operator_keys():
	with pytest.raises(ValueError):
		SecureAnimalShelterDAO.sanitizeInputDict({"profile.age": 3})
	# Top level operator keys are stripped rather than raising
	clean = SecureAnimalShelterDAO.sanitizeInputDict({"$where": "this.x"})
	assert clean == {}
