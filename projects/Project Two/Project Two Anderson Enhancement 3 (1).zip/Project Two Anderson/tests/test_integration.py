# **************************************
# CS 499 - Enhancement 3
# Original - CS 340 Project 2
# Author - Cheyenne Anderson
# Date - October 2, 2026
# **************************************

#imports
import os
import sys
import uuid
import base64
import pytest

# Integration test that exercises real MongoDB CRUD operations.
# This test is marked with pytest.mark.integration and is skipped unless
# MONGO_URI is present in the environment.
sys.path.insert(0, os.path.abspath("."))

from SecureAnimalShelterDAO import SecureAnimalShelterDAO
from SecurityManager import SecurityManager

@pytest.mark.integration
def test_integration_crud_against_real_mongo():
	# Requires MONGO_URI env var, e.g. mongodb://localhost:27017
	mongo_uri = os.environ.get("MONGO_URI")
	if not mongo_uri:
		pytest.skip("MONGO_URI not set; skipping integration test")

	# Use a unique db name to avoid interfering with existing data
	db_name = f"test_shelter_{uuid.uuid4().hex}"
	dao = SecureAnimalShelterDAO(uri=mongo_uri, db_name=db_name)

	# Use provided SECURITY_JWT_SECRET if set, otherwise generate a secure one for the test
	sec = os.environ.get("SECURITY_JWT_SECRET")
	if sec:
		SecurityManager.JWT_SECRET = sec
	else:
		SecurityManager.JWT_SECRET = base64.urlsafe_b64encode(os.urandom(48)).decode("utf-8")

	token = SecurityManager.issue_token("int-user", ["READ_USER", "WRITE_USER", "ADMIN"])

	# Run CRUD operations with the token
	try:
		# Insert
		doc = {"name": "IntegrationBuddy", "species": "dog", "age": 3}
		inserted_id = dao.insert(doc, token)
		assert inserted_id is not None

		# Find
		results = dao.find({"name": "IntegrationBuddy"}, token)
		assert any(r.get("name") == "IntegrationBuddy" for r in results)

		# Update
		res = dao.update({"name": "IntegrationBuddy"}, {"$set": {"status": "available"}}, token)
		# update_many returns a result object with modified_count on success
		assert hasattr(res, "modified_count")

		# Delete
		del_res = dao.delete({"name": "IntegrationBuddy"}, token)
		assert hasattr(del_res, "deleted_count")
	finally:
		# Drop the test database to clean up
		try:
			dao.client.drop_database(db_name)
		except Exception:
			pass
