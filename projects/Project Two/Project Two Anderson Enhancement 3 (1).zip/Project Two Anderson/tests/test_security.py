# **************************************
# CS 499 - Enhancement 3
# Original - CS 340 Project 2
# Author - Cheyenne Anderson
# Date - October 2, 2026
# **************************************

# Imports
import os
import sys
import types
import base64
import pytest
from unittest import mock

# Tests for SecurityManager and SecureAnimalShelterDAO.
# These unit tests cover sanitization, token issuance/validation, and RBAC checks.
# They use mocking for MongoDB to avoid requiring a running database.
# Ensure project root is on path for imports when tests run from workspace root
sys.path.insert(0, os.path.abspath("."))

from SecurityManager import SecurityManager
from SecureAnimalShelterDAO import SecureAnimalShelterDAO
from SecurityLogger import log_info

# Use a secure random JWT secret for tests to avoid PyJWT InsecureKeyLengthWarning
SecurityManager.JWT_SECRET = base64.urlsafe_b64encode(os.urandom(48)).decode("utf-8")

# Test password hashing and verification
def test_password_hash_and_verify():
	if SecurityManager.hash_password is None:
		pytest.skip("bcrypt not installed")
	pw = "correcthorsebatterystaple"
	hashed = SecurityManager.hash_password(pw)
	assert hashed is not None
	assert SecurityManager.verify_password(pw, hashed)
	assert not SecurityManager.verify_password("wrong", hashed)

#Test token issuance and validation with role checks
def test_issue_and_validate_token():
	SecurityManager.TOKEN_TTL = 3600
	token = SecurityManager.issue_token("user1", ["READ_USER", "WRITE_USER"])
	assert token is not None
	assert SecurityManager.validate_token(token)
	assert SecurityManager.validate_token(token, required_role="READ_USER")
	assert not SecurityManager.validate_token(token, required_role="ADMIN")

	
#Test sanitization rejects operator keys
def test_sanitize_input_rejects_operators():
	bad = {"$where": "this.age > 2"}
	# operator keys should be stripped rather than raising
	clean = SecureAnimalShelterDAO.sanitizeInputDict(bad)
	assert clean == {}

	bad2 = {"name": "Buddy", "profile.age": 3}
	with pytest.raises(ValueError):
		SecureAnimalShelterDAO.sanitizeInputDict(bad2)


#Test sanitization filters unknown fields
def test_sanitize_input_filters_unknown_fields():
	inp = {"name": "Fido", "unknown": "x", "age": 4}
	clean = SecureAnimalShelterDAO.sanitizeInputDict(inp)
	assert "unknown" not in clean
	assert clean["name"] == "Fido"
	assert clean["age"] == 4

# Test that update payload sanitization allows only $set
@mock.patch("SecureAnimalShelterDAO.MongoClient")
def test_dao_crud_with_auth(mock_mongo_client):
	# Prepare mock DB/collection
	mock_db = mock.Mock()
	mock_collection = mock.Mock()
	mock_collection.find.return_value = [{"name": "Fido", "age": 4}]
	mock_db.animals = mock_collection
	# Use MagicMock so magic methods like __getitem__ can be assigned
	mock_client_instance = mock.MagicMock()
	mock_client_instance.__getitem__.return_value = mock_db
	mock_mongo_client.return_value = mock_client_instance
	# Create DAO with mocked MongoClient
	dao = SecureAnimalShelterDAO(uri="mongodb://localhost:27017", db_name="shelter")

	# Create a token that has READ_USER role
	token = SecurityManager.issue_token("u1", ["READ_USER"])

	# find should work with READ_USER
	results = dao.find({"name": "Fido"}, token)
	assert isinstance(results, list)
	assert results[0]["name"] == "Fido"

	# insert requires WRITE_USER
	token_no_write = SecurityManager.issue_token("u1", ["READ_USER"])
	with pytest.raises(PermissionError):
		dao.insert({"name": "New"}, token_no_write)

	# update requires WRITE_USER
	with pytest.raises(PermissionError):
		dao.update({"name": "Fido"}, {"$set": {"status": "adopted"}}, token_no_write)

	# delete requires ADMIN
	with pytest.raises(PermissionError):
		dao.delete({"name": "Fido"}, token_no_write)

# Test that sanitizeUpdatePayload allows only $set and raises for others
def test_sanitize_update_payload_allows_only_set():
	good = {"$set": {"status": "available"}}
	clean = SecureAnimalShelterDAO.sanitizeUpdatePayload(good)
	assert "$set" in clean
	assert clean["$set"]["status"] == "available"
# Test that other operators raise ValueError
	bad = {"$unset": {"status": ""}}
	with pytest.raises(ValueError):
		SecureAnimalShelterDAO.sanitizeUpdatePayload(bad)


# If running tests directly, print note
if __name__ == "__main__":
	print("Run 'pytest' to execute tests")
