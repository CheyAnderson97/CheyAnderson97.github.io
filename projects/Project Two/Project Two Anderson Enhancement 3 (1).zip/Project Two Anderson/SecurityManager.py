#**************************************
# CS 499 - Enhancement 3
# Original - CS 340 Project 2
# Author - Cheyenne Anderson
# Date - October 2, 2026
#**************************************


import os
import time
from typing import Dict, List, Optional

# Optional external dependencies: bcrypt and PyJWT.
# Import failures are handled so the module can still load in limited environments.
try:
	import bcrypt
except Exception:
	bcrypt = None

# PyJWT powers token encoding/decoding; keep optional for graceful degradation.
try:
	import jwt
except Exception:
	jwt = None

from SecurityLogger import log_error, log_info
# base64 is used for generating a secure random development JWT secret.
import base64
# This module centralizes authentication security helpers for the application.


class SecurityManager:
	#Security helpers for password hashing and JWT lifecycle operations.

	#Features:
	#- Hash and verify passwords with bcrypt.
	#- Issue and validate JWT tokens containing user roles.

	#Configuration:
	#- SECURITY_JWT_SECRET: strong signing secret 
	#- SECURITY_TOKEN_TTL: token lifetime in seconds 

	#If no SECURITY_JWT_SECRET is provided, a secure random secret is generated at
	#import time for development convenience. Tokens signed with that generated secret
	#will not survive process restarts.
	#For production deployments, provide a stable secret through environment variables.
	

	# Determine JWT secret: prefer environment variable; if not set, generate a secure
	# random default for development use. 
	_env_secret = os.environ.get("SECURITY_JWT_SECRET", None)
	if _env_secret is None:
		# generate a secure random secret (base64 encoded) for local/dev runs
		JWT_SECRET = base64.urlsafe_b64encode(os.urandom(48)).decode("utf-8")
		log_info("jwt-secret-generated", "No SECURITY_JWT_SECRET set; generated a secure default (dev only)")
	else:
		if len(_env_secret.encode("utf-8")) < 32:
			raise RuntimeError(
				f"SECURITY_JWT_SECRET is too short ({len(_env_secret.encode('utf-8'))} bytes). Provide a secret of at least 32 bytes.")
		JWT_SECRET = _env_secret
	# Token validity duration (seconds).
	TOKEN_TTL = int(os.environ.get("SECURITY_TOKEN_TTL", "3600"))
	# HMAC SHA-256 signing algorithm for JWT.
	ALGORITHM = "HS256"
	
	#class level methods for password hashing and JWT management.
	@classmethod
	def hash_password(cls, plain: str) -> Optional[bytes]:
		#Hash a plaintext password using bcrypt.
		#Returns:
		#	bytes: bcrypt hash for storage when successful.
		#	None: if bcrypt is unavailable.
		if bcrypt is None:
			log_error("bcrypt-missing", "bcrypt library is not installed")
			return None
		pw = plain.encode("utf-8")
		hashed = bcrypt.hashpw(pw, bcrypt.gensalt())
		return hashed

	@classmethod
	def verify_password(cls, plain: str, hashed: bytes) -> bool:
		#Verify plaintext password against a stored bcrypt hash.
		#Returns True only when the password matches the provided hash.	
		if bcrypt is None:
			log_error("bcrypt-missing", "bcrypt library is not installed")
			return False
		try:
			return bcrypt.checkpw(plain.encode("utf-8"), hashed)
		except Exception as e:
			log_error("bcrypt-verify-failed", str(e))
			return False

	@classmethod
	def issue_token(cls, user_id: str, roles: List[str]) -> Optional[str]:
		#Create and sign a JWT for a user identity and role set.
		#The token includes subject (`sub`), roles, issued-at (`iat`), and expiry (`exp`).	
		if jwt is None:
			log_error("jwt-missing", "PyJWT library is not installed")
			return None
		now = int(time.time())
		# Construct the JWT payload with standard claims and custom roles.
		payload = {
			"sub": user_id,
			"roles": roles,
			"iat": now,
			"exp": now + cls.TOKEN_TTL,
		}
		# Encode the payload into a JWT string using the configured secret and algorithm.
		try:
			token = jwt.encode(payload, cls.JWT_SECRET, algorithm=cls.ALGORITHM)
			# PyJWT >=2 returns str, older returns bytes
			if isinstance(token, bytes):
				token = token.decode("utf-8")
			return token
		except Exception as e:
			log_error("jwt-issue-failed", str(e))
			return None

	@classmethod
	def validate_token(cls, token: str, required_role: Optional[str] = None) -> bool:
		#Validate JWT integrity/expiry and optionally enforce role-based access.

		#Args:
		#	token: Encoded JWT string.
		#	required_role: Optional role that must be present in token claims.
		if jwt is None:
			log_error("jwt-missing", "PyJWT library is not installed")
			return False
		try:
			payload = jwt.decode(token, cls.JWT_SECRET, algorithms=[cls.ALGORITHM])
		except Exception as e:
			# Covers signature failures, expiry, malformed token, and decode errors.
			log_info("jwt-validate-failed", str(e))
			return False
		# If a required_role was specified, ensure it is present in the token claims
		if required_role:
			roles = payload.get("roles", [])
			# Enforce caller-provided RBAC requirement.
			if required_role not in roles:
				log_info("rbac-failed", f"required={required_role} roles={roles}")
				return False
		return True

	@classmethod
	def decode_token(cls, token: str) -> Optional[Dict]:
		#Decode and return JWT payload after signature/expiry checks.

		#Useful when callers need claims content. Returns None on failure.
		if jwt is None:
			log_error("jwt-missing", "PyJWT library is not installed")
			return None
		try:
			payload = jwt.decode(token, cls.JWT_SECRET, algorithms=[cls.ALGORITHM])
			return payload
		except Exception as e:
			log_info("jwt-decode-failed", str(e))
			return None
