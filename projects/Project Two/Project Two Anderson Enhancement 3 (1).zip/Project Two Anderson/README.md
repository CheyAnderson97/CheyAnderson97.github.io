#**************************************
# CS 499 - Enhancement 3
# Original - CS 340 Project 2
# Author - Cheyenne Anderson
# Date - October 2, 2026
#**************************************
Secure Animal Shelter DAO

This workspace contains a small update with a secure DAO example for a Python/MongoDB project, including input sanitization, RBAC via JWT tokens, and unit tests.

Files created from original project:
- SecurityLogger.py: centralized logging helpers
- SecurityManager.py: password hashing and JWT token helpers 
- SecureAnimalShelterDAO.py: DAO with whitelist based input sanitization and safe DB wrappers
- tests/test_security.py: pytest unit tests that mock pymongo

Dependencies:
- Python 3.8+
- pymongo
- bcrypt
- PyJWT
- pytest (for running tests)

Install packages (recommended):

pip install pymongo bcrypt PyJWT pytest

Running tests:

pytest -q

Running the demo (main.py) and integration notes
-----------------------------------------------
main.py is a small safe entrypoint that demonstrates a read operation using
SecureAnimalShelterDAO. By default it will not connect to a database
unless you provide a MONGO_URI environment variable.

PowerShell example to run the demo against a local MongoDB:

$env:MONGO_URI = "mongodb://localhost:27017"
$bytes = New-Object 'Byte[]' 48
(New-Object System.Security.Cryptography.RNGCryptoServiceProvider).GetBytes($bytes)
$env:SECURITY_JWT_SECRET = [Convert]::ToBase64String($bytes)
python main.py

To set environment variables permanently for your user (PowerShell):

setx MONGO_URI "mongodb://localhost:27017"
setx SECURITY_JWT_SECRET "<paste-base64-secret-here>"

Notes for integration runs
- Ensure MONGO_URI points to a MongoDB instance accessible from your machine or CI.
- SECURITY_JWT_SECRET should be at least 32 bytes (base64 of 48 random bytes is a good choice).
- Integration tests in tests/test_integration.py are marked with pytest.mark.integration and will be
  skipped unless MONGO_URI is present in the environment. 
  
Run them with:

python -m pytest -q -m integration

To run only the unit tests (excluding integration markers), use:
python -m pytest -q

Sanitization rules and RBAC separation
--------------------------------------
- Sanitization rules:
  - All input is processed into a new sanitized dictionary (no in-place edits).
  - Top-level operator keys beginning with "$" are stripped and not forwarded to MongoDB.
  - Keys containing a dot (".") are rejected to avoid ambiguous nested field access.
  - Only top-level keys in ALLOWED_FIELDS are accepted; unexpected fields are ignored.
  - Values are sanitized recursively: strings are cleaned and truncated, numbers and booleans are allowed,
	lists and nested dicts are processed recursively, and unsupported types raise an error.
  - Update payloads allow only a top-level "$set" whose contents are sanitized.

- RBAC & separation of concerns:
  - SecurityManager is responsible for password hashing (bcrypt), issuing JWTs, and validating tokens/roles.
  - SecureAnimalShelterDAO delegates authentication/authorization checks to SecurityManager.validate_token
	before executing any DB operation.
  - The DAO focuses on input validation, safe DB access, and returning generic errors while SecurityManager
	centralizes auth logic; this keeps responsibilities separated and testable.


