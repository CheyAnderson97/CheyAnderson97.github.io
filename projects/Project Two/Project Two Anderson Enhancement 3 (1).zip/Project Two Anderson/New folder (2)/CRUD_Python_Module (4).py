# **************************************
# CS 499 - Enhancement 3
# Original - CS 340 Project 2
# Author - Cheyenne Anderson
# Date - October 2, 2026
# **************************************

from pymongo import MongoClient
from bson.objectid import ObjectId

#creates class AnimalSheleter with methods for CRUD operations and error handling
class AnimalShelter(object):

    def __init__(self, username, password):
        # Initializing the MongoClient to access the MongoDB server
        # Connection constants for the AAC database
        # initializes the database and collection AAC and animals
        USER = username
        PASS = password
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'
        #attempts the connection and prints error if unable
        try:
            self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER, PASS, HOST, PORT))
            self.database = self.client['%s' % (DB)]
            self.collection = self.database['%s' % (COL)]
            print("Successfully connected to the AAC database.")
        except Exception as e:
            print(f"Could not connect to MongoDB: {e}")
    # creates the create logic and error message if unable
    def create(self, data):
        if data is not None:
            try:
                insert_result = self.collection.insert_one(data) 
                return insert_result.acknowledged
            except Exception as e:
                print(f"An error occurred during Create: {e}")
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")
    # creates the read logic and prints error if unable to find it
    def read(self, query):
        try:
            # find() returns a cursor; we convert it to a list for easier client use
            cursor = self.collection.find(query)
            return list(cursor)
        except Exception as e:
            print(f"An error occurred during Read: {e}")
            return []
    #creates the update logic to update database and errror message if unable
    def update(self, query, update_data):
        if query is not None and update_data is not None:
            try:
                # Using update_many for broad functionality as requested
                result = self.collection.update_many(query, {"$set": update_data})
                return result.modified_count
            except Exception as e:
                print(f"An error occurred during Update: {e}")
                return 0
        else:
            return 0
    #creates the delete logic and error message if unable to delete
    def delete(self, query):
        if query is not None:
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except Exception as e:
                print(f"An error occurred during Delete: {e}")
                return 0
        else:
            return 0