**************************************
# CS 499 - Enhancement 3
# Original - CS 340 Project 2
# Author - Cheyenne Anderson
# Date - October 2, 2026
**************************************

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    def __init__(self, username, password):
        # Change these to point to the local Codio database
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'
        
        self.client = MongoClient('mongodb://%s:%s@%s:%d/?authSource=admin' % (username, password, HOST, PORT))
        self.database = self.client[DB]
        self.collection = self.database[COL]
    #creates the create logic and exception error message if unsuccessful
    def create(self, data):
        if data is not None:
            try:
                insert_result = self.collection.insert_one(data) 
                return insert_result.acknowledged
            except Exception as e:
                print(f"Detailed Error: {e}")
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")
    #creates the read logic and error mesasage if unable to find in search
    def read(self, query=None):
        try:
            search_query = query if query is not None else {}
            cursor = self.collection.find(search_query)
            return list(cursor)
        except Exception as e:
            print(f"Error reading documents: {e}")
            return []
    #creates the update logic and the error message if unable to update
    def update(self, query, update_data):
        if query is not None and update_data is not None:
            try:
                result = self.collection.update_many(query, {"$set": update_data})
                return result.modified_count
            except Exception as e:
                print(f"An error occurred during update: {e}")
                return 0
        else:
            return 0
    #creates the delete option and an error message if unable to delete
    def delete(self, query):
        if query is not None:
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except Exception as e:
                print(f"An error occurred during delete: {e}")
                return 0
        else:
            return 0