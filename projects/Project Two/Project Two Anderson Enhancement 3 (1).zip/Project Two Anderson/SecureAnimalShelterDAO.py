# **************************************
# CS 499 - Enhancement 3
# Original - CS 340 Project 2
# Author - Cheyenne Anderson
# Date - October 2, 2026
# **************************************

#imports	
import os
from typing import Any, Dict, List, Optional

# Optional external dependency: pymongo. Import failures are handled so the module can still load in limited environments.
try:
	from pymongo import MongoClient, errors as pymongo_errors
except Exception:
	MongoClient = None
	pymongo_errors = None
from SecurityLogger import log_error, log_info, log_warning
from SecurityManager import SecurityManager


class SecureAnimalShelterDAO:
	#Secure DAO for animal shelter operations.

	#This class centralizes safe access to the MongoDB collection "animals".
	#It performs:
	#- Input sanitization 
	#- Authorization checks by delegating to SecurityManager
	#- Safe MongoDB client initialization with TLS enforced

	#The DAO returns safe errors and logs detailed errors internally to avoid leaking DB internals.

	# Minimal whitelist of allowed fields clients can query or update
	ALLOWED_FIELDS = {"name", "species", "age", "status", "intake_date"}
	# Maximum length of sanitized strings to protect from extremely long inputs
	MAX_STRING_LEN = 256

	def __init__(self, uri: str, db_name: str = "shelter", username: Optional[str] = None, password: Optional[str] = None):
		#Initialize MongoClient with secure defaults and pick the target DB.

		#uri: MongoDB connection URI
		#db_name: database to use
		#username/password: optional credentials (use MongoDB)
		if MongoClient is None:
			raise RuntimeError("pymongo is required but not installed")
		# Use TLS by default and enforce valid certificates in production
		kwargs = {"tls": True,
				  "tlsAllowInvalidCertificates": False,
				  "serverSelectionTimeoutMS": 5000}
		if username:
			kwargs.update({"username": username, "password": password})
		# Avoid retryWrites by default to make behavior predictable
		kwargs.setdefault("retryWrites", False)
		# Create the client 
		self.client = MongoClient(uri, **kwargs)
		self.db = self.client[db_name]
		log_info("dao-init", f"Connected to {db_name}")

	@classmethod
	def _sanitize_string(cls, s: str) -> str:
		#Sanitize strings by removing non-printable characters and truncating.

		#This helps avoid control characters and very long values.
		cleaned = "".join(ch for ch in s if ch.isprintable())
		if len(cleaned) > cls.MAX_STRING_LEN:
			return cleaned[: cls.MAX_STRING_LEN]
		return cleaned

	@classmethod
	def sanitizeInputDict(cls, input_map: Dict[str, Any]) -> Dict[str, Any]:
		#Recursively sanitize an input dict and return a NEW sanitized dict.

		#Rules:
		#- Strip keys that start with '$' (operators) at any nesting level
		#- Reject dotted keys that may imply nested field access
		#- Only allow top-level keys in ALLOWED_FIELDS 
		#- Sanitize string values and recursively process dicts and lists	
		if not isinstance(input_map, dict):
			raise ValueError("Input must be a dict")
		
		# Helper function to sanitize values recursively
		def sanitize_value(val):
			# Scalars
			if isinstance(val, str):
				return cls._sanitize_string(val)
			if isinstance(val, (int, float, bool)):
				return val
			# Dict -> sanitize recursively
			if isinstance(val, dict):
				clean_sub: Dict[str, Any] = {}
				for sk, sv in val.items():
					# Strip nested operator keys starting with '$'
					if not isinstance(sk, str):
						log_warning("sanitize-reject-key-nested", f"key={sk}")
						raise ValueError(f"Invalid nested key: {sk}")
					if sk.startswith("$"):
						# Instead of raising, strip operator keys to be forgiving
						log_info("sanitize-strip-operator-nested", f"stripped nested operator key={sk}")
						continue
					if "." in sk:
						# Dotted keys are ambiguous and rejected
						log_warning("sanitize-reject-key-nested", f"key={sk}")
						raise ValueError(f"Invalid nested key: {sk}")
					# Recursively sanitize nested values
					clean_sub[sk] = sanitize_value(sv)
				return clean_sub
			# List -> sanitize elements recursively
			if isinstance(val, list):
				clean_list: List[Any] = []
				for item in val:
					clean_list.append(sanitize_value(item))
				return clean_list
			# Other types are not supported
			log_warning("sanitize-reject-type", f"type={type(val)}")
			raise ValueError(f"Unsupported type in input: {type(val)}")

		clean: Dict[str, Any] = {}
		for k, v in input_map.items():
			# Strip top-level operator keys starting with '$'
			if not isinstance(k, str):
				log_warning("sanitize-reject-key", f"key={k}")
				raise ValueError(f"Invalid key: {k}")
			if k.startswith("$"):
				# Strip operator keys instead of failing to be permissive
				log_info("sanitize-strip-operator", f"stripped operator key={k}")
				continue
			if "." in k:
				log_warning("sanitize-reject-key", f"key={k}")
				raise ValueError(f"Invalid key: {k}")
			if k not in cls.ALLOWED_FIELDS:
				# Ignore unexpected fields silently (can be changed to raise)
				log_info("sanitize-ignore-field", f"field={k}")
				continue
			# Sanitize value (recursively handles nested dicts/lists)
			clean[k] = sanitize_value(v)
		return clean

	@classmethod
	def sanitizeUpdatePayload(cls, update_map: Dict[str, Any]) -> Dict[str, Any]:
		#Allow only {$set: { ... }} updates and sanitize the set payload.

		#This prevents arbitrary update operators being used by callers.
		if not isinstance(update_map, dict):
			raise ValueError("update payload must be a dict")
		if "$set" not in update_map:
			raise ValueError("Only $set updates are allowed")
		set_payload = update_map["$set"]
		if not isinstance(set_payload, dict):
			raise ValueError("$set must be a dict")
		clean_set = cls.sanitizeInputDict(set_payload)
		return {"$set": clean_set}

	def authorize_and_execute(self, user_token: str, required_role: str, fn):
		#Validate the token/role and execute the provided DB function.

		#This method delegates token validation to SecurityManager to keep the
		#DAO focused on data access concerns.
		if not SecurityManager.validate_token(user_token, required_role=required_role):
			log_info("auth-fail", f"required={required_role}")
			raise PermissionError("Unauthorized")
		# Authorization passed; execute provided function. Database errors are
		# handled by each DAO method to control what is exposed to callers.
		return fn()

	def find(self, raw_filter: Dict[str, Any], user_token: str) -> List[Dict[str, Any]]:
		#Find documents matching the sanitized filter. Returns list or [] on DB error.
		filt = self.sanitizeInputDict(raw_filter)
		def op():
			cursor = self.db.animals.find(filt, projection={f: 1 for f in self.ALLOWED_FIELDS})
			return list(cursor)
		try:
			return self.authorize_and_execute(user_token, "READ_USER", op)
		except Exception as e:
			# If this was a PyMongo error, log internally and return empty list
			if pymongo_errors is not None and isinstance(e, pymongo_errors.PyMongoError):
				log_error("db-error", str(e))
				return []
			# Propagate non-db errors 
			raise

	def insert(self, doc: Dict[str, Any], user_token: str) -> Any:
		#Insert a sanitized document. On DB error raise a generic RuntimeError.
		clean_doc = self.sanitizeInputDict(doc)
		def op():
			return self.db.animals.insert_one(clean_doc).inserted_id
		try:
			return self.authorize_and_execute(user_token, "WRITE_USER", op)
		except Exception as e:
			# For DB errors hide internal details and return a generic error
			if pymongo_errors is not None and isinstance(e, pymongo_errors.PyMongoError):
				log_error("db-error", str(e))
				raise RuntimeError("Database error")
			raise

	def update(self, filter_raw: Dict[str, Any], update_raw: Dict[str, Any], user_token: str) -> Any:
		#Update documents matching filter using sanitized $set payload.
		filt = self.sanitizeInputDict(filter_raw)
		update = self.sanitizeUpdatePayload(update_raw)
		def op():
			return self.db.animals.update_many(filt, update)
		try:
			return self.authorize_and_execute(user_token, "WRITE_USER", op)
		# Handle DB errors by logging and raising a generic error
		except Exception as e:
			if pymongo_errors is not None and isinstance(e, pymongo_errors.PyMongoError):
				log_error("db-error", str(e))
				raise RuntimeError("Database error")
			raise

	# Delete operation is restricted to ADMIN role	
	def delete(self, filter_raw: Dict[str, Any], user_token: str) -> Any:
		#Delete documents matching the sanitized filter (ADMIN only).
		filt = self.sanitizeInputDict(filter_raw)
		def op():
			return self.db.animals.delete_many(filt)
		try:
			return self.authorize_and_execute(user_token, "ADMIN", op)
		# Handle DB errors by logging and raising a generic error
		except Exception as e:
			if pymongo_errors is not None and isinstance(e, pymongo_errors.PyMongoError):
				log_error("db-error", str(e))
				raise RuntimeError("Database error")
			raise
