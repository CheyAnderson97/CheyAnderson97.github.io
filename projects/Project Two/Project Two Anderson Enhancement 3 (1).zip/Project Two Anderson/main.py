#**************************************
# CS 499 - Enhancement 3
# Original - CS 340 Project 2
# Author - Cheyenne Anderson
# Date - October 2, 2026
#**************************************

#This is intentionally read-only and will not connect to a database unless
#MONGO_URI and optional credentials are provided with environment variables.

#Usage:
#  python main.py

# Set MONGO_URI to actually connect, e.g.:
#   setx MONGO_URI "mongodb://localhost:27017"

# Import os for environment variables and project security/data access helpers
import os
from SecurityManager import SecurityManager
from SecureAnimalShelterDAO import SecureAnimalShelterDAO


def demo():
	#Run a minimal demo read operation against the animals collection.

	#The function checks for MONGO_URI and SECURITY_JWT_SECRET in the
	#environment and only proceeds when a URI is present. 
	#This keeps the demo safe for users who do not want to run a database locally.
	# Read MongoDB connection URI from environment configuration
	uri = os.environ.get("MONGO_URI")
	if not uri:
		# No DB configured, print instructions and exit
		print("MONGO_URI not set — demo will not connect. Set MONGO_URI to run against a DB.")
		return

	# Use a secure secret from env if available 
	sec = os.environ.get("SECURITY_JWT_SECRET")
	if sec:
		# Set the JWT secret for the SecurityManager
		SecurityManager.JWT_SECRET = sec

	# Create DAO instance for the shelter database.
	dao = SecureAnimalShelterDAO(uri=uri, db_name="shelter")
	# Issue a demo token with read permissions for sample query execution.
	token = SecurityManager.issue_token("demo-user", ["READ_USER"]) or ""

	# Run a sample read operation and print returned documents.
	print("Running a simple find (may return empty list):")
	try:
		results = dao.find({"name": "Fido"}, token)
		print(results)
	except Exception as e:
		# Surface only, a generic error message to the user
		print("Error during demo find: ", str(e))

# if this script is run directly, execute the demo function
if __name__ == "__main__":
	demo()
