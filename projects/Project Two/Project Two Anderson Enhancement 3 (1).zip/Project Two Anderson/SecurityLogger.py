# **************************************
# CS 499 - Enhancement 3
# Original - CS 340 Project 2
# Author - Cheyenne Anderson
# Date - October 2, 2026
# **************************************

# Import standard logging and sys modules for emitting logs to stdout/stderr
import logging
import sys

# Create a named logger used across the secure DAO modules to centralize logs
_logger = logging.getLogger("secure_daos")
# Default to INFO level so important security events are visible
_logger.setLevel(logging.INFO)

# Create a stream handler that writes logs to stdout 
_handler = logging.StreamHandler(sys.stdout)
# Set the handler level to INFO as well
_handler.setLevel(logging.INFO)
# Use a compact, timestamped format for log lines
_formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
_handler.setFormatter(_formatter)

# Avoid adding duplicate handlers when module is re-imported during testing
if not _logger.handlers:
	_logger.addHandler(_handler)

# Define logging functions for different severity levels, each accepting an event identifier and optional details.
def log_info(event: str, details: str = ""):
	#Log an informational security event.

	# Parameters:
	# - event: short machine-friendly event identifier
	# - details: optional readable details
	# Emit an INFO-level log with event and details
	_logger.info(f"{event} - {details}")


def log_warning(event: str, details: str = ""):
	#Log a warning-level security event (suspicious but non-fatal).

	# Parameters:
	# - event: short machine-friendly event identifier
	# - details: optional readable details
	# Emit a warning-level log
	_logger.warning(f"{event} - {details}")


def log_error(event: str, details: str = ""):
	#Log an error-level security event 

	# Parameters:
	# - event: short machine-friendly event identifier
	# - details: optional readable details	
	# Emit an error-level log
	_logger.error(f"{event} - {details}")

#
def log_debug(event: str, details: str = ""):
	#Log debug information. Avoid including secrets in these logs.

	# Parameters:
	# - event: short machine-friendly event identifier
	# - details: optional readable details
	# Emit a debug-level log 
	_logger.debug(f"{event} - {details}")
