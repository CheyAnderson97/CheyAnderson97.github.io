//*********************************************************
// Name: Cheyenne Anderson
//CS:499 Project One Enhancement 
//Date: 9/19/2026
//Original: CS 320 Project One
//*********************************************************
package projectOneTests;
 
import static org.junit.jupiter.api.Assertions.*;
 
import java.util.Calendar;
import java.util.Date;
 
import org.junit.jupiter.api.BeforeEach; 
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
 
import Main.Appointment;
import Main.AppointmentService;
 
class AppointmentServiceTest {
 
    //Define createDate
    private Date createDate(int year, int month, int day) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month);
        calendar.set(Calendar.DAY_OF_MONTH, day);
        // Set time fields to 0 
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }

    // Helper to create a Date with explicit hour/minute for time tests
    // Keeps milliseconds and seconds zeroed for comparisons.

    // Define createDateTime with hour and minute for testing ranges
    private Date createDateTime(int year, int month, int day, int hour, int minute) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month);
        calendar.set(Calendar.DAY_OF_MONTH, day);
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }
    
    @BeforeEach
    void setup() {
        // Reset the ID counter before each test run
        Appointment.resetIdGenerator(); 
    }

    @Test
    @DisplayName("Test to ensure that service can add an appointment.")
    @Order(1)
    void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        // Arrange: create service and add a single appointment
        service.addAppointment(createDate(2027, Calendar.JANUARY, 1), "Description");

        // Assert: first appointment id is "0" and the appointment exists
        assertNotNull(service.getAppointment("0"), "Appointment was not added correctly.");
    }
    
    @Test
    @DisplayName("Test to Update appointment date")
    @Order(2)
    void testUpdateAppointmentDate() {
        AppointmentService service = new AppointmentService();
        
        // 1. ADD THE APPOINTMENT 
        Date initialDate = createDate(2027, Calendar.JANUARY, 1);
        service.addAppointment(initialDate, "Description");
        
        String appointmentID = service.getAppointment("0").getAppointmentID(); 
 
        // 2. DEFINE NEW DATE
        Date newDate = createDate(3027, Calendar.FEBRUARY, 2);
        
        // 3. UPDATE 
        service.updateAppointmentDate(newDate, appointmentID);
        
        // 4. ASSERT
        // Verify the stored appointment now has the updated start date
        assertEquals(newDate, service.getAppointment(appointmentID).getAppointmentDate(), "Appointment date was not updated.");
    }
 
    @Test
    @DisplayName("Test to Update appointment description.")
    @Order(3)
    void testUpdateAppointmentDesc() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(createDate(2027, Calendar.JANUARY, 1), "Description");
        
        String appointmentID = service.getAppointment("0").getAppointmentID();
        String updatedDesc = "Updated Description";
        
        service.updateAppointmentDesc(updatedDesc, appointmentID);
        
        // Confirm the description was replaced by the service
        assertEquals(updatedDesc, service.getAppointment(appointmentID).getAppointmentDesc(), "Appointment description was not updated.");
    }
 
    @Test
    @DisplayName("Test to ensure that service correctly deletes appointments.")
    @Order(4)
    void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(createDate(2027, Calendar.JANUARY, 1), "Description");
        
        String appointmentID = service.getAppointment("0").getAppointmentID();
        
        service.deleteAppointment(appointmentID);
        
        // After deletion, the store should be empty
        assertEquals(0, service.getAppointmentCount(), "The appointment was not deleted.");
    }
    
    @Test
    @DisplayName("Test getAppointment returns null for nonexistent ID.")
    @Order(5)
    void testGetNonexistentAppointment() {
        AppointmentService service = new AppointmentService();
        // Check for an invalid ID in an empty list
        // getAppointment returns null when the id is not present
        assertNull(service.getAppointment("999"), "Should return null for a nonexistent appointment ID.");
    }

    @Test
    @DisplayName("Test deleteAppointment handles nonexistent ID.")
    @Order(6)
    void testDeleteNonexistentAppointment() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(createDate(2027, Calendar.JANUARY, 1), "Description");
        
        service.deleteAppointment("999");
        
        // The single appointment should still be in the list
        // Deleting a missing id must be per service contract
        assertEquals(1, service.getAppointmentCount(), "List size should not change when deleting nonexistent ID.");
    }

    @Test
    @DisplayName("Test updateAppointmentDate handles nonexistent ID.")
    @Order(7)
    void testUpdateAppointmentDateNonexistent() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(createDate(2027, Calendar.JANUARY, 1), "Description");
        
        Date originalDate = service.getAppointment("0").getAppointmentDate();
        
        service.updateAppointmentDate(createDate(3000, Calendar.JANUARY, 1), "999");
        
        // Updating a missing id should not affect existing appointments
        assertEquals(originalDate, service.getAppointment("0").getAppointmentDate(), "Appointment date should not change when updating nonexistent ID.");
    }

    @Test
    @DisplayName("Test updateAppointmentDesc handles nonexistent ID.")
    @Order(8)
    void testUpdateAppointmentDescNonexistent() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(createDate(2027, Calendar.JANUARY, 1), "Original Description");
        
        String originalDesc = service.getAppointment("0").getAppointmentDesc();
        
        service.updateAppointmentDesc("New Description", "999");
        
        // Ensure description unchanged after attempting to update missing id
        assertEquals(originalDesc, service.getAppointment("0").getAppointmentDesc(), "Appointment description should not change when updating nonexistent ID.");
    }
    
    @Test
    @DisplayName("Test displayAppointmentList runs (for coverage)")
    @Order(9)
    void testDisplayAppointmentListCoverage() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(createDate(2027, Calendar.JANUARY, 1), "Test");
        // Exercise the display method 
        service.displayAppointmentList();
    }

    @Test
    @DisplayName("Test overlapping appointment is rejected")
    @Order(10)
    void testAddAppointmentWithOverlap() {
        AppointmentService service = new AppointmentService();
        Date start1 = createDateTime(2027, Calendar.JANUARY, 1, 10, 0);
        Date end1 = createDateTime(2027, Calendar.JANUARY, 1, 11, 0);
        service.addAppointment(start1, end1, "First");

        Date start2 = createDateTime(2027, Calendar.JANUARY, 1, 10, 30);
        Date end2 = createDateTime(2027, Calendar.JANUARY, 1, 11, 30);

        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(start2, end2, "Overlap"));
    }

    @Test
    @DisplayName("Test non-overlapping appointment is allowed")
    @Order(11)
    void testAddAppointmentNoOverlap() {
        AppointmentService service = new AppointmentService();
        Date start1 = createDateTime(2027, Calendar.JANUARY, 1, 10, 0);
        Date end1 = createDateTime(2027, Calendar.JANUARY, 1, 11, 0);
        service.addAppointment(start1, end1, "First");

        // starts exactly at previous end - should not overlap
        Date start2 = createDateTime(2027, Calendar.JANUARY, 1, 11, 0);
        Date end2 = createDateTime(2027, Calendar.JANUARY, 1, 12, 0);
        service.addAppointment(start2, end2, "Second");

        assertEquals(2, service.getAppointmentCount(), "Both appointments should be added when not overlapping.");
    }
}