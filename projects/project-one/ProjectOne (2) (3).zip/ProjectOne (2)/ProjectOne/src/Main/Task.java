//*********************************************************
// Name: Cheyenne Anderson
//CS 320 Project One
//*********************************************************
package Main;

public class Task {

	  public String taskId;
	  public String name;
	  public String description;

	  public Task() {
	    taskId = "INITIAL";
	    name = "INITIAL";
	    description = "INITIAL DESCRIPTION";
	  }

	  public Task(String taskId) {
	    checkTaskId(taskId);
	    name = "INITIAL";
	    description = "INITIAL DESCRIPTION";
	  }

	  public Task(String taskId, String name) {
	    checkTaskId(taskId);
	    setName(name);
	    description = "INITIAL DESCRIPTION";
	  }

	  public Task(String taskId, String name, String desc) {
	    checkTaskId(taskId);
	    setName(name);
	    setDescription(desc);
	  }

	  public final String getTaskId() { return taskId; }

	  public final String getName() { return name; }
	  //errors for task name
	  public void setName(String name) {
	    if (name == null || name.length() > 20) {
	      throw new IllegalArgumentException(
	          "Task name is invalid. Ensure it is shorter than 20 characters, and not empty.");
	    } else {
	      this.name = name;
	    }
	  }
	  //errors for task description
	  public final String getDescription() { return description; }

	  public void setDescription(String taskDescription) {
	    if (taskDescription == null || taskDescription.length() > 50) {
	      throw new IllegalArgumentException(
	          "Task description is invalid. Ensure it is shorter than 50 characters, and not empty.");
	    } else {
	      this.description = taskDescription;
	    }
	  }
	  //error for taskID
	  private void checkTaskId(String taskId) {
	    if (taskId == null || taskId.length() > 10) {
	      throw new IllegalArgumentException(
	          "Error: The task ID was null or longer than 10 characters");
	    } else {
	      this.taskId = taskId;
	    }
	  }
	}