//*********************************************************
// Name: Cheyenne Anderson
//CS 320 Project One
//*********************************************************
package Main;


import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {
	//ArrayList of appointments
	public ArrayList<Appointment> appointmentList = new ArrayList<Appointment>();

	// Display the full list of appointment
	public void displayAppointmentList() {
		for (int counter = 0; counter < appointmentList.size(); counter++) {
			System.out.println("\t Appointment ID: " + appointmentList.get(counter).getAppointmentID());
			System.out.println("\t Appointment Date: " + appointmentList.get(counter).getAppointmentDate());
			System.out.println("\t Appointment Description: " + appointmentList.get(counter).getAppointmentDesc());
		}
	}

	// Adds a new appointment 
	public void addAppointment(Date appointmentDate, String appointmentDesc) {
		// Creates the new appointment
		Appointment appointment = new Appointment(appointmentDate, appointmentDesc);
		appointmentList.add(appointment);
	}

	// returns an appointment
	public Appointment getAppointment(String appointmentID) {
	    // Initialize to null. If no match is found, null is returned.
	    Appointment appointment = null; 
	    for (int counter = 0; counter < appointmentList.size(); counter++) {
	        if (appointmentList.get(counter).getAppointmentID().contentEquals(appointmentID)) {
	            appointment = appointmentList.get(counter);
	            break; // stop searching
	        }
	    }
	    return appointment; 
	}

	// Deletes appointment
	// find the correct appointment to delete from the list
	// Report if none is found
	public void deleteAppointment(String appointmentID) {
		for (int counter = 0; counter < appointmentList.size(); counter++) {
			if (appointmentList.get(counter).getAppointmentID().equals(appointmentID)) {
				appointmentList.remove(counter);
				break;
			}
			if (counter == appointmentList.size() - 1) {
				System.out.println("Appointment ID: " + appointmentID + " not found.");
			}
		}
	}

	public void updateAppointmentDate(Date updatedDate, String appointmentID) {
	    for (int counter = 0; counter < appointmentList.size(); counter++) {
	        if (appointmentList.get(counter).getAppointmentID().equals(appointmentID)) {
	            appointmentList.get(counter).setAppointmentDate(updatedDate);
	            return; // exit the method once updated
	        }
	    }
	    // If we reach here, the ID was not found
	    System.out.println("Appointment ID: " + appointmentID + " not found.");
	}

	// Updates the appointment description.
	public void updateAppointmentDesc(String updatedString, String appointmentID) {
		for (int counter = 0; counter < appointmentList.size(); counter++) {
			if (appointmentList.get(counter).getAppointmentID().equals(appointmentID)) {
				appointmentList.get(counter).setAppointmentDesc(updatedString);
				break;
			}
			if (counter == appointmentList.size() - 1) {
				System.out.println("Appointment ID: " + appointmentID + " not found.");
			}
		}
	}
}