//*********************************************************
// Name: Cheyenne Anderson
//CS 320 Project One
//*********************************************************
package Main;

public class Contact {
    // contactID is final 
    private final String contactID;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    /**
     * Constructor for a Contact object. 
     */
    public Contact(String contactID, String firstName, String lastName, String phone, String address) {
        // --- Contact ID Validation: Not null, <= 10 characters
        if (contactID == null || contactID.length() > 10) {
            throw new IllegalArgumentException("Invalid Contact ID: Cannot be null and must be 10 characters or less.");
        }
        this.contactID = contactID; // Set once

        // Use setters for initial validation of updatable fields
        setFirstName(firstName);
        setLastName(lastName);
        setPhone(phone);
        setAddress(address);
    }

    //  Getters 
    public String getContactID() {
        return contactID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    //  Setters with Validation 

    /**
     * Sets the first name after validating it's not null and <= 10 characters.
     */
    public void setFirstName(String firstName) {
        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("Invalid First Name: Cannot be null and must be 10 characters or less.");
        }
        this.firstName = firstName;
    }

    /**
     * Sets the last name after validating it's not null and <= 10 characters.
     */
    public void setLastName(String lastName) {
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Invalid Last Name: Cannot be null and must be 10 characters or less.");
        }
        this.lastName = lastName;
    }

    /**
     * Sets the phone number after validating it's not null and exactly 10 digits.
     */
    public void setPhone(String phone) {
        // Checking for exactly 10 characters and not null
        if (phone == null || phone.length() != 10) {
            throw new IllegalArgumentException("Invalid Phone Number: Cannot be null and must be exactly 10 digits.");
        }

        this.phone = phone;
    }

    /**
     * Sets the address after validating it's not null and <= 30 characters.
     */
    public void setAddress(String address) {
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Invalid Address: Cannot be null and must be 30 characters or less.");
        }
        this.address = address;
    }
}