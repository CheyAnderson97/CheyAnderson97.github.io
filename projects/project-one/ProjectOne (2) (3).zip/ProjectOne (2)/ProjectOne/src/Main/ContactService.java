//*********************************************************
// Name: Cheyenne Anderson
//CS 320 Project One
//*********************************************************
package Main;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private final Map<String, Contact> contactList = new HashMap<>();

    /**
     * Adds a new contact to the service
     * @param contact The Contact object to add.
     */
    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("Contact can't be null.");
        }
        String contactID = contact.getContactID();
        
        if (contactList.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact ID already exists.");
        }
        contactList.put(contactID, contact);
    }

    /**
     * Deletes a contact by its unique ID.
     * @param contactID The ID of the contact to delete.
     */
    public void deleteContact(String contactID) {
        if (contactList.remove(contactID) == null) {
            throw new IllegalArgumentException("Contact ID, not found for deletion.");
        }
    }

    /**
     * Updates fields of an existing contact
     * Uses Contact object's setters for field-level validation.
     */
    public void updateContact(String contactID, String firstName, String lastName, String phone, String address) {
        Contact contact = contactList.get(contactID);

        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found for update.");
        }

        // Use the Contact class setters for validation
        if (firstName != null) {
            contact.setFirstName(firstName);
        }
        if (lastName != null) {
            contact.setLastName(lastName);
        }
        if (phone != null) {
            contact.setPhone(phone);
        }
        if (address != null) {
            contact.setAddress(address);
        }
    }
    
    /**
     * Helper method to retrieve a contact for testing purposes.
     */
    public Contact getContact(String contactID) {
        return contactList.get(contactID);
    }
}
