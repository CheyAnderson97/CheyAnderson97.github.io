/****************************************************
* Name: Cheyenne Anderson
*CS 320 Project One
*****************************************************
*/

package Main;

import java.util.concurrent.atomic.AtomicLong;
import java.util.Calendar;
import java.util.Date;

public class Appointment {   //for an appointment with a unique ID, date, and description


	private final String appointmentID; //unique ID for appointment
	private Date appointmentDate; //appointment date
	private String appointmentDesc;  //appointment description
	private static AtomicLong idGenerator = new AtomicLong();   //generator for ID creation
	
	//*********************************************************
	
	// CONSTRUCTORS
	
	//*********************************************************
	
	@SuppressWarnings("deprecation")
	public Appointment(Date appointmentDate, String appointmentDesc) {
		
		// Appointment ID
		// The idGenerator is static to prevent duplicates and have unique IDs
		this.appointmentID = String.valueOf(idGenerator.getAndIncrement());
		
		//validates and sets date of appointment
		if (appointmentDate == null) { //defaults date to null if input null
			this.appointmentDate = new Date(2022, Calendar.JANUARY, 1);
		} else if (appointmentDate.before(new Date())) {  //creates exception if date is in past
			throw new IllegalArgumentException("Cannot make appointment before current date.");
		} else {
			this.appointmentDate = appointmentDate;
		}
		
		//validates and sets appointment description
		if (appointmentDesc == null || appointmentDesc.isEmpty()) { //default description if input NULL
			this.appointmentDesc = "NULL";
		} else if (appointmentDesc.length() > 50) {    //cuts off description if more than 50 characters
			this.appointmentDesc = appointmentDesc.substring(0, 50);
		} else {
			this.appointmentDesc = appointmentDesc;
		}
	}
	//************************************************************************************************
	
	// GETTERS
	
	//************************************************************************************************
	
	//gets and returns appointment ID
	public String getAppointmentID() {
		return appointmentID;
	}
	
	//gets and returns appointment date
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	
	//gets and returns appointment description 
	public String getAppointmentDesc() {
		return appointmentDesc;
	}
	
	//************************************************************************************************
	
	// SETTERS
	
	//************************************************************************************************

	@SuppressWarnings("deprecation")
	//Sets a new date for the appointment validating it is not in the past  
	public void setAppointmentDate(Date appointmentDate) {  //validate and set appointment date
		if (appointmentDate == null) {
			appointmentDate = new Date(2022, Calendar.JANUARY, 1); //default date if input is null
		} else if (appointmentDate.before(new Date())) {
			throw new IllegalArgumentException("Cannot make appointment before current date.");   //throws exception if date is past
		} else {
			this.appointmentDate = appointmentDate;
		}
	}
	
	//sets description for appointment and cuts off at 50 characters if needed 
	public void setAppointmentDesc(String appointmentDesc) {   //validate and set appointment description
		if (appointmentDesc == null || appointmentDesc.isEmpty()) {
			this.appointmentDesc = "NULL";
		} else if (appointmentDesc.length() > 50) {
			this.appointmentDesc = appointmentDesc.substring(0, 50); //cuts off description if more than 50 characters
		} else {
			this.appointmentDesc = appointmentDesc;
		}
	}
	// resets the ID generator to 0 for testing
    public static void resetIdGenerator() {
        idGenerator = new AtomicLong();
    }
}
