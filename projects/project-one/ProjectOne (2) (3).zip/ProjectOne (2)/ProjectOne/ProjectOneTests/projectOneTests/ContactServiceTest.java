//*********************************************************
// Name: Cheyenne Anderson
//CS 320 Project One
//*********************************************************
package projectOneTests;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import Main.Contact;
import Main.ContactService;

import static org.junit.jupiter.api.Assertions.*;

class ContactServiceTest {

    private ContactService service;
    private Contact testContact1;
    private final String validID = "ID001";
    private final String validFName = "Alice";
    private final String validLName = "Smith";
    private final String validPhone = "1234567890";
    private final String validAddress = "123 Main St";

    // Setup runs before each test method to ensure a clean state
    @BeforeEach
    void setUp() {
        service = new ContactService();
        testContact1 = new Contact(validID, validFName, validLName, validPhone, validAddress);
        service.addContact(testContact1);
    }

    // Add Tests 

    // Test successful addition of a unique contact
    @Test
    void testAddContactSuccess() {
        Contact newContact = new Contact("ID002", "Bob", "Jones", "0987654321", "456 Oak Ave");
        service.addContact(newContact);
        assertNotNull(service.getContact("ID002"), "Contact should be successfully added.");
    }

    // Test adding a contact with a duplicate ID fails
    @Test
    void testAddContactDuplicateID() {
        assertThrows(IllegalArgumentException.class, () -> {
            // Attempt to add a contact with the same ID as testContact1 ("ID001")
            Contact duplicateContact = new Contact(validID, "Charlie", "Brown", "5555555555", "789 Pine Ln");
            service.addContact(duplicateContact);
        });
    }

    //  Delete Tests 

    // Test successful deletion of an existing contact
    @Test
    void testDeleteContactSuccess() {
        service.deleteContact(validID);
        assertNull(service.getContact(validID), "Contact should be successfully deleted and not retrievable.");
    }

    // Test deleting a non-existent contact fails
    @Test
    void testDeleteContactNotFound() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("ID999"); // Non-existent ID
        });
    }

    // Update Tests

    // Test successful update of First Name
    @Test
    void testUpdateFirstNameSuccess() {
        String newFirstName = "Alicia";
        service.updateContact(validID, newFirstName, null, null, null);
        assertEquals(newFirstName, service.getContact(validID).getFirstName(), "First Name should be updated.");
    }

    // Test successful update of Phone
    @Test
    void testUpdatePhoneSuccess() {
        String newPhone = "5551234567";
        service.updateContact(validID, null, null, newPhone, null);
        assertEquals(newPhone, service.getContact(validID).getPhone(), "Phone should be updated.");
    }
    
    // Test multiple fields can be updated at once
    @Test
    void testUpdateMultipleFieldsSuccess() {
        String newLastName = "Parker";
        String newAddress = "New York, NY 10001";
        service.updateContact(validID, null, newLastName, null, newAddress);
        
        Contact updatedContact = service.getContact(validID);
        assertAll("Multiple fields updated",
            () -> assertEquals(newLastName, updatedContact.getLastName()),
            () -> assertEquals(newAddress, updatedContact.getAddress())
        );
    }

    // Test update with invalid data fails
    @Test
    void testUpdateInvalidData() {
        String originalLastName = service.getContact(validID).getLastName();
        assertThrows(IllegalArgumentException.class, () -> {
            // Attempt to update with an invalid Last Name (> 10 chars)
            service.updateContact(validID, null, "ExtremelyLongLastName", null, null);
        });
        // Assert that the original value was NOT changed
        assertEquals(originalLastName, service.getContact(validID).getLastName(), "Last Name should remain unchanged after failed update.");
    }
    
    // Test update of a non-existent contact fails
    @Test
    void testUpdateContactNotFound() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateContact("ID999", "NewName", null, null, null);
        });
    }
}