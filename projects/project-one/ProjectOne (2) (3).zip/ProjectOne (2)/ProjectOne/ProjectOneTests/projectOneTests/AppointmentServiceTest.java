//*********************************************************
// Name: Cheyenne Anderson
//CS 320 Project One
//*********************************************************
package projectOneTests;
 
import static org.junit.jupiter.api.Assertions.*;
 
import java.util.Calendar;
import java.util.Date;
 
import org.junit.jupiter.api.BeforeEach; 
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
 
import Main.Appointment;
import Main.AppointmentService;
 
class AppointmentServiceTest {
 
    //Define createDate
    private Date createDate(int year, int month, int day) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month);
        calendar.set(Calendar.DAY_OF_MONTH, day);
        // Set time fields to 0 
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }
    
    @BeforeEach
    void setup() {
        // Reset the ID counter before each test run
        Appointment.resetIdGenerator(); 
    }

    @Test
    @DisplayName("Test to ensure that service can add an appointment.")
    @Order(1)
    void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(createDate(2027, Calendar.JANUARY, 1), "Description");
        
        // The ID of the first added appointment will be "0"
        assertNotNull(service.getAppointment("0"), "Appointment was not added correctly.");
    }
    
    @Test
    @DisplayName("Test to Update appointment date")
    @Order(2)
    void testUpdateAppointmentDate() {
        AppointmentService service = new AppointmentService();
        
        // 1. ADD THE APPOINTMENT 
        Date initialDate = createDate(2027, Calendar.JANUARY, 1);
        service.addAppointment(initialDate, "Description");
        
        String appointmentID = service.appointmentList.get(0).getAppointmentID(); 
 
        // 2. DEFINE NEW DATE
        Date newDate = createDate(3027, Calendar.FEBRUARY, 2);
        
        // 3. UPDATE 
        service.updateAppointmentDate(newDate, appointmentID);
        
        // 4. ASSERT
        assertEquals(newDate, service.getAppointment(appointmentID).getAppointmentDate(), "Appointment date was not updated.");
    }
 
    @Test
    @DisplayName("Test to Update appointment description.")
    @Order(3)
    void testUpdateAppointmentDesc() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(createDate(2027, Calendar.JANUARY, 1), "Description");
        
        String appointmentID = service.appointmentList.get(0).getAppointmentID();
        String updatedDesc = "Updated Description";
        
        service.updateAppointmentDesc(updatedDesc, appointmentID);
        
        assertEquals(updatedDesc, service.getAppointment(appointmentID).getAppointmentDesc(), "Appointment description was not updated.");
    }
 
    @Test
    @DisplayName("Test to ensure that service correctly deletes appointments.")
    @Order(4)
    void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(createDate(2027, Calendar.JANUARY, 1), "Description");
        
        String appointmentID = service.appointmentList.get(0).getAppointmentID();
        
        service.deleteAppointment(appointmentID);
        
        assertEquals(0, service.appointmentList.size(), "The appointment was not deleted.");
    }
    
    @Test
    @DisplayName("Test getAppointment returns null for nonexistent ID.")
    @Order(5)
    void testGetNonexistentAppointment() {
        AppointmentService service = new AppointmentService();
        // Check for an invalid ID in an empty list
        assertNull(service.getAppointment("999"), "Should return null for a nonexistent appointment ID.");
    }

    @Test
    @DisplayName("Test deleteAppointment handles nonexistent ID.")
    @Order(6)
    void testDeleteNonexistentAppointment() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(createDate(2027, Calendar.JANUARY, 1), "Description");
        
        service.deleteAppointment("999");
        
        // The single appointment should still be in the list
        assertEquals(1, service.appointmentList.size(), "List size should not change when deleting nonexistent ID.");
    }

    @Test
    @DisplayName("Test updateAppointmentDate handles nonexistent ID.")
    @Order(7)
    void testUpdateAppointmentDateNonexistent() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(createDate(2027, Calendar.JANUARY, 1), "Description");
        
        Date originalDate = service.appointmentList.get(0).getAppointmentDate();
        
        service.updateAppointmentDate(createDate(3000, Calendar.JANUARY, 1), "999");
        
        assertEquals(originalDate, service.appointmentList.get(0).getAppointmentDate(), "Appointment date should not change when updating nonexistent ID.");
    }

    @Test
    @DisplayName("Test updateAppointmentDesc handles nonexistent ID.")
    @Order(8)
    void testUpdateAppointmentDescNonexistent() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(createDate(2027, Calendar.JANUARY, 1), "Original Description");
        
        String originalDesc = service.appointmentList.get(0).getAppointmentDesc();
        
        service.updateAppointmentDesc("New Description", "999");
        
        assertEquals(originalDesc, service.appointmentList.get(0).getAppointmentDesc(), "Appointment description should not change when updating nonexistent ID.");
    }
    
    @Test
    @DisplayName("Test displayAppointmentList runs (for coverage)")
    @Order(9)
    void testDisplayAppointmentListCoverage() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(createDate(2027, Calendar.JANUARY, 1), "Test");
        service.displayAppointmentList();
    }
}