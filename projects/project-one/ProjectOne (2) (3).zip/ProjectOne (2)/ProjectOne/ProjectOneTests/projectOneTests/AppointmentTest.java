//*********************************************************
// Name: Cheyenne Anderson
//CS 320 Project One
//*********************************************************
package projectOneTests;
 
import static org.junit.jupiter.api.Assertions.*;
 
import java.util.Date;
import java.util.Calendar;
 
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import Main.Appointment;
 
class AppointmentTest {
 
    //Define createDate ---
    private Date createDate(int year, int month, int day) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month);
        calendar.set(Calendar.DAY_OF_MONTH, day);
        // Set time fields to 0 for consistent comparison
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }
    
    @BeforeEach
    void setup() {
        // Reset the ID counter 
        Appointment.resetIdGenerator(); 
    }
    
    // Appointment ID 
    @Test
    @DisplayName("Appointment ID cannot have more than 10 characters")
    void testAppointmentIDWithMoreThanTenCharacters() {
        Main.Appointment appointment = new Main.Appointment(createDate(2027, Calendar.JANUARY, 1), "Description");
        if (appointment.getAppointmentID().length() > 10) {
            fail("Appointment ID has more than 10 characters.");
        }
    }
    
    // Constructor Description length test
    @Test
    @DisplayName("Task Description cannot have more than 50 characters")
    void testAppointmentDescWithMoreThanFiftyCharacters() {
        String longDescription = "123456789 is nine characters long" 
                               + "123456789 is another nine characters long" 
                               + "123456789 is another nine characters long"
                               + "123456789 is another nine characters long"
                               + "Five more chars."; 
        Main.Appointment appointment = new Main.Appointment(createDate(2027, Calendar.JANUARY, 1), longDescription);
        assertEquals(50, appointment.getAppointmentDesc().length(), "Appointment Description should be truncated to 50 characters.");
    }
    
    // Constructor Date past exception test
    @Test
    @DisplayName("Appointment Date constructor cannot be before current date (Exception)")
    void testConstructorPastDateException() {
        Date pastDate = createDate(2000, Calendar.JANUARY, 1);
        assertThrows(IllegalArgumentException.class, () -> {
            new Main.Appointment(pastDate, "Description");
        }, "Should throw IllegalArgumentException for a past date.");
    }

    // Constructor Date null test
    @Test
    @DisplayName("Task Date shall not be null (Constructor handles null)")
    void testAppointmentDateNotNull() {
        Main.Appointment appointment = new Main.Appointment(null, "Description");
        assertNotNull(appointment.getAppointmentDate(), "Appointment Date was null and should have been assigned a default value.");
    }
    
    // Constructor Description null test
    @Test
    @DisplayName("Task Description shall not be null (Constructor handles null/empty)")
    void testAppointmentDescNotNull() {
        Main.Appointment appointment = new Main.Appointment(createDate(2027, Calendar.JANUARY, 1), null);
        assertEquals("NULL", appointment.getAppointmentDesc(), "Appointment Description was null and should be set to 'NULL'.");
        
        Main.Appointment appointmentEmpty = new Main.Appointment(createDate(2027, Calendar.JANUARY, 1), "");
        assertEquals("NULL", appointmentEmpty.getAppointmentDesc(), "Appointment Description was empty and should be set to 'NULL'.");
    }
    
    // Setter Date past exception test
    @Test
    @DisplayName("Appointment Date setter cannot set a past date (Exception)")
    void testSetterPastDateException() {
        Main.Appointment appointment = new Main.Appointment(createDate(2027, Calendar.JANUARY, 1), "Valid");
        Date pastDate = createDate(2000, Calendar.JANUARY, 1);
        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentDate(pastDate);
        }, "Setter should throw IllegalArgumentException for a past date.");
    }
    
    // Setter Date null test
    @Test
    @DisplayName("Appointment Date setter handles null input")
    void testSetterNullDate() {
        Main.Appointment appointment = new Main.Appointment(createDate(2027, Calendar.JANUARY, 1), "Valid");
        appointment.setAppointmentDate(null);
        assertNotNull(appointment.getAppointmentDate(), "Setter should set a default date if null is passed.");
    }
    
    // Setter Description long string test
    @Test
    @DisplayName("Appointment Description setter truncates long description")
    void testSetDescriptionTooLong() {
        Main.Appointment appointment = new Main.Appointment(createDate(2027, Calendar.JANUARY, 1), "Valid");
        String longDesc = "This is a very long description that must be over fifty characters for testing truncation.";
        appointment.setAppointmentDesc(longDesc);
        assertEquals(50, appointment.getAppointmentDesc().length(), "Setter should truncate description to 50 characters.");
    }
    
    // Setter Description null/empty test
    @Test
    @DisplayName("Appointment Description setter handles null or empty input")
    void testSetDescriptionNullOrEmpty() {
        Main.Appointment appointment = new Main.Appointment(createDate(2027, Calendar.JANUARY, 1), "Valid");
        appointment.setAppointmentDesc(null);
        assertEquals("NULL", appointment.getAppointmentDesc(), "Setter should default to NULL for null input.");
        appointment.setAppointmentDesc("");
        assertEquals("NULL", appointment.getAppointmentDesc(), "Setter should default to NULL for empty input.");
    }
}