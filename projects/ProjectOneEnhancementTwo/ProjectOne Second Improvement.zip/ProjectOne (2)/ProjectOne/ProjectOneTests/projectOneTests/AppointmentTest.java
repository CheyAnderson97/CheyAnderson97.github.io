//*********************************************************
// Name: Cheyenne Anderson
//CS:499 Project One Enhancement 
//Date: 9/19/2026
//Original: CS 320 Project One
//*********************************************************

package projectOneTests;
 
import static org.junit.jupiter.api.Assertions.*;
 
import java.util.Date;
import java.util.Calendar;
 
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import Main.Appointment;
 
class AppointmentTest {
 
    //Define createDate 
    private Date createDate(int year, int month, int day) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month);
        calendar.set(Calendar.DAY_OF_MONTH, day);
        // Set time fields to 0 for consistent comparison
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }

    // Small helper used to build test dates reliably.
        // Tests rely on exact
        // equality comparisons so we zero time components for determinism.
    
    @BeforeEach
    void setup() {
        // Reset the ID counter 
        Appointment.resetIdGenerator(); 
    }
    
    // Appointment ID 
    @Test
    @DisplayName("Appointment ID cannot have more than 10 characters")
    void testAppointmentIDWithMoreThanTenCharacters() {
        // Arrange: build a simple appointment 
        Main.Appointment appointment = new Main.Appointment(createDate(2027, Calendar.JANUARY, 1), "Description");
        // Assert: appointment id length must be within the expected limit
        if (appointment.getAppointmentID().length() > 10) {
            fail("Appointment ID has more than 10 characters.");
        }
    }
    
    // Constructor Description length test
    @Test
    @DisplayName("Task Description cannot have more than 50 characters")
    void testAppointmentDescWithMoreThanFiftyCharacters() {
        String longDescription = "123456789 is nine characters long" 
                               + "123456789 is another nine characters long" 
                               + "123456789 is another nine characters long"
                               + "123456789 is another nine characters long"
                               + "Five more chars."; 
        // Arrange: create appointment with overly long description
        Main.Appointment appointment = new Main.Appointment(createDate(2027, Calendar.JANUARY, 1), longDescription);
        // Assert: builder truncates description to 50 chars
        assertEquals(50, appointment.getAppointmentDesc().length(), "Appointment Description should be truncated to 50 characters.");
    }
    
    // Constructor Date past exception test
    @Test
    @DisplayName("Appointment Date constructor cannot be before current date (Exception)")
    void testConstructorPastDateException() {
        Date pastDate = createDate(2000, Calendar.JANUARY, 1);
        // Assert: constructing with a past date must throw
        assertThrows(IllegalArgumentException.class, () -> {
            new Main.Appointment(pastDate, "Description");
        }, "Should throw IllegalArgumentException for a past date.");
    }

    // Constructor Date null test
    @Test
    @DisplayName("Task Date shall not be null (Constructor handles null)")
    void testAppointmentDateNotNull() {
        // Arrange: construct with null start date 
        Main.Appointment appointment = new Main.Appointment(null, "Description");
        // Assert: builder assigned a non null default date
        assertNotNull(appointment.getAppointmentDate(), "Appointment Date was null and should have been assigned a default value.");
    }
    
    // Constructor Description null test
    @Test
    @DisplayName("Task Description shall not be null (Constructor handles null/empty)")
    void testAppointmentDescNotNull() {
        // Arrange: construct with null description
        Main.Appointment appointment = new Main.Appointment(createDate(2027, Calendar.JANUARY, 1), null);
        // Assert: description normalized to "NULL"
        assertEquals("NULL", appointment.getAppointmentDesc(), "Appointment Description was null and should be set to 'NULL'.");

        // Arrange: construct with empty description
        Main.Appointment appointmentEmpty = new Main.Appointment(createDate(2027, Calendar.JANUARY, 1), "");
        // Assert: empty description normalized to "NULL"
        assertEquals("NULL", appointmentEmpty.getAppointmentDesc(), "Appointment Description was empty and should be set to 'NULL'.");
    }
    
    // Setter Date past exception test
    @Test
    @DisplayName("Appointment Date setter cannot set a past date (Exception)")
    void testSetterPastDateException() {
        Date pastDate = createDate(2000, Calendar.JANUARY, 1);
        // Assert: builder rejects past start dates
        assertThrows(IllegalArgumentException.class, () -> {
            new Main.Appointment.Builder()
                .setStartDate(pastDate)
                .setAppointmentDesc("Valid")
                .build();
        }, "Building with a past start date should throw IllegalArgumentException.");
    }
    
    // Setter Date null test
    @Test
    @DisplayName("Appointment Date setter handles null input")
    void testSetterNullDate() {
        // Arrange: builder called with null start date
        Main.Appointment built = new Main.Appointment.Builder()
            .setStartDate(null)
            .setAppointmentDesc("Valid")
            .build();
        // Assert: default date assigned
        assertNotNull(built.getAppointmentDate(), "Builder should set a default date if null is passed.");
    }
    
    // Setter Description long string test
    @Test
    @DisplayName("Appointment Description setter truncates long description")
    void testSetDescriptionTooLong() {
        // Arrange: builder called with very long description
        Main.Appointment built = new Main.Appointment.Builder()
            .setStartDate(createDate(2027, Calendar.JANUARY, 1))
            .setAppointmentDesc("This is a very long description that must be over fifty characters for testing truncation.")
            .build();
        // Assert: description truncated to 50 chars
        assertEquals(50, built.getAppointmentDesc().length(), "Builder should truncate description to 50 characters.");
    }
    
    // Setter Description - null test
    @Test
    @DisplayName("Appointment Description setter handles null input")
    void testSetDescriptionNull() {
        // Arrange: builder with null description
        Main.Appointment builtNull = new Main.Appointment.Builder()
            .setStartDate(createDate(2027, Calendar.JANUARY, 1))
            .setAppointmentDesc(null)
            .build();
        // Assert: normalized to "NULL"
        assertEquals("NULL", builtNull.getAppointmentDesc(), "Builder should default to NULL for null input.");

        // Arrange: builder with empty description
        Main.Appointment builtEmpty = new Main.Appointment.Builder()
            .setStartDate(createDate(2027, Calendar.JANUARY, 1))
            .setAppointmentDesc("")
            .build();
        // Assert: normalized to "NULL"
        assertEquals("NULL", builtEmpty.getAppointmentDesc(), "Builder should default to NULL for empty input.");
    }
}