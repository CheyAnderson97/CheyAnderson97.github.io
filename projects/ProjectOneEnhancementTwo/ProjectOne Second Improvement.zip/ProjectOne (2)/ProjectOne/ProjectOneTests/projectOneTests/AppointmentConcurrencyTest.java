//*********************************************************
// Name: Cheyenne Anderson
//CS:499 Project One Enhancement 
//Date: 9/25/2026
//Original: CS 320 Project One
//*********************************************************
// Concurrency test to verify AppointmentService thread-safety
//*********************************************************
package projectOneTests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import Main.Appointment;
import Main.AppointmentService;

class AppointmentConcurrencyTest {

	@BeforeEach
	void setup() {
		Appointment.resetIdGenerator();
	}

	@Test
	@DisplayName("Concurrent adds should be thread-safe and produce unique IDs")
	void testConcurrentAddsProduceUniqueIds() throws InterruptedException {
		final int TASKS = 100;
		final AppointmentService service = new AppointmentService();

		ExecutorService exec = Executors.newFixedThreadPool(16);
		CountDownLatch startLatch = new CountDownLatch(1);
		CountDownLatch doneLatch = new CountDownLatch(TASKS);
		ConcurrentLinkedQueue<Exception> errors = new ConcurrentLinkedQueue<>();

		for (int i = 0; i < TASKS; i++) {
			final int idx = i;
			exec.submit(() -> {
				try {
					// Wait for the simultaneous start
					startLatch.await();
					// Use distinct future dates to avoid overlapping-range checks
					java.util.Calendar cal = java.util.Calendar.getInstance();
					cal.set(2030, java.util.Calendar.JANUARY, 1);
					cal.add(java.util.Calendar.SECOND, idx);
					service.addAppointment(cal.getTime(), "Concurrent " + idx);
				} catch (Exception e) {
					errors.add(e);
				} finally {
					doneLatch.countDown();
				}
			});
		}

		// Start tasks
		startLatch.countDown();
		// Wait for completion
		boolean completed = doneLatch.await(10, TimeUnit.SECONDS);
		exec.shutdownNow();
		assertTrue(completed, "Not all tasks completed in time");
		if (!errors.isEmpty()) {
			fail("Exceptions occurred during concurrent adds: " + errors.peek());
		}

		// Validate count and uniqueness of IDs
		assertEquals(TASKS, service.getAppointmentCount(), "Appointment count should match number of concurrent adds.");
		Set<String> ids = service.getAppointmentList().stream().map(a -> a.getAppointmentID()).collect(Collectors.toSet());
		assertEquals(TASKS, ids.size(), "Appointment IDs must be unique across concurrent additions.");
	}
}
