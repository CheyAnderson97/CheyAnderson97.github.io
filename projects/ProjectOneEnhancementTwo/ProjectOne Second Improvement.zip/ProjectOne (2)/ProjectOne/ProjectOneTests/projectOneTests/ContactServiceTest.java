//*********************************************************
// Name: Cheyenne Anderson
//CS:499 Project One Enhancement 
//Date: 9/19/2026
//Original: CS 320 Project One
//*********************************************************
package projectOneTests;

import Main.Contact;
import Main.ContactService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    void setUp() {
        service = new ContactService();
    }

    // setUp creates a new ContactService for each test ensuring a clean
    // in-memory store and avoiding test inter-dependencies.

    @Test
    @DisplayName("Test successful contact creation using Builder")
    void testAddContactSuccess() {
        Contact contact = new Contact.Builder()
                .setContactId("1001")
                .setFirstName("Shay")
                .setLastName("Anderson")
                .setPhone("1234567890")
                .setAddress("123 Main Street")
                .build();

        service.addContact(contact);
        assertEquals(1, service.getContactCount());
        assertEquals("Shay", service.getContact("1001").getFirstName());
    }

    @Test
    @DisplayName("Test adding duplicate contact ID throws exception")
    void testAddDuplicateContactThrowsException() {
        Contact contact1 = new Contact.Builder()
                .setContactId("1001")
                .setFirstName("Shay")
                .setLastName("Anderson")
                .setPhone("1234567890")
                .setAddress("123 Main Street")
                .build();

        Contact contact2 = new Contact.Builder()
                .setContactId("1001")
                .setFirstName("Jane")
                .setLastName("Doe")
                .setPhone("0987654321")
                .setAddress("456 Elm Street")
                .build();

        service.addContact(contact1);
        assertThrows(IllegalArgumentException.class, () -> service.addContact(contact2));
    }

    @Test
    @DisplayName("Test updating fields on existing contact")
    void testUpdateContactFields() {
        Contact contact = new Contact.Builder()
                .setContactId("1001")
                .setFirstName("Shay")
                .setLastName("Anderson")
                .setPhone("1234567890")
                .setAddress("123 Main Street")
                .build();

        service.addContact(contact);
        service.updateFirstName("1001", "Cheyenne");
        service.updatePhone("1001", "5555555555");

        Contact updated = service.getContact("1001");
        assertEquals("Cheyenne", updated.getFirstName());
        assertEquals("5555555555", updated.getPhone());
    }

    @Test
    @DisplayName("Test deleting existing contact")
    void testDeleteContact() {
        Contact contact = new Contact.Builder()
                .setContactId("1001")
                .setFirstName("Shay")
                .setLastName("Anderson")
                .setPhone("1234567890")
                .setAddress("123 Main Street")
                .build();

        service.addContact(contact);
        service.deleteContact("1001");
        assertEquals(0, service.getContactCount());
    }

    @Test
    @DisplayName("Test invalid phone validation constraint")
    void testInvalidPhoneThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact.Builder()
                    .setContactId("1002")
                    .setFirstName("Alex")
                    .setLastName("Smith")
                    .setPhone("12345") // Invalid length
                    .setAddress("789 Oak Ave")
                    .build();
        });
    }
}