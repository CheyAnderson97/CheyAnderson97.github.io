//*********************************************************
// Name: Cheyenne Anderson
//CS:499 Project One Enhancement 
//Date: 9/19/2026
//Original: CS 320 Project One
//*********************************************************
package projectOneTests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

import Main.TaskService;

//creates class taskservicetest
class TaskServiceTest {

  private String id, name, description;
  private String tooLongName, tooLongDescription;

  @BeforeEach
  void setUp() {
    id = "1234567890";
    name = "This is Twenty Chars";
    description = "The task object shall have a required description.";
    tooLongName = "This is way too long to be a task name";
    tooLongDescription =
        "The task object shall have a required description String field that cannot be longer than 50 characters. The description field shall not be null.";
  }

  // The setup above initializes common test fixture values used across
  // multiple test to keep each test efficient and focused on a single behavior.
  //test to test for new taskservice
  @Test
  void newTaskTest() {
    // Arrange: create service and add a default task with no custom name/desc
    TaskService service = new TaskService();
    service.newTask();
    // Assert: the generated id exists and is not the placeholder value
    Assertions.assertNotNull(service.getTaskList().get(0).getTaskId());
    Assertions.assertNotEquals("INITIAL",
                               service.getTaskList().get(0).getTaskId());
  }
  //test for new task name
  @Test
  void newTaskNameTest() {
    // Arrange: create service and add a task with a specific name
    TaskService service = new TaskService();
    service.newTask(name);
    // Assert: the stored task has the requested name
    Assertions.assertNotNull(service.getTaskList().get(0).getName());
    Assertions.assertEquals(name, service.getTaskList().get(0).getName());
  }
  //test for new task description
  @Test
  void newTaskDescriptionTest() {
    // Arrange: create service and add a task with name and description
    TaskService service = new TaskService();
    service.newTask(name, description);
    // Assert: description matches provided value
    Assertions.assertNotNull(service.getTaskList().get(0).getDescription());
    Assertions.assertEquals(description,
                            service.getTaskList().get(0).getDescription());
  }
  //test name task too long
  @Test
  void newTaskTooLongNameTest() {
    // Arrange: create service
    TaskService service = new TaskService();
    // Assert: providing a too-long name results in an IllegalArgumentException
    Assertions.assertThrows(IllegalArgumentException.class,
                            () -> service.newTask(tooLongName));
  }
  // test new task description too long
  @Test
  void newTaskTooLongDescriptionTest() {
    // Arrange: service instance
    TaskService service = new TaskService();
    // Assert: too-long description triggers validation failure
    assertThrows(IllegalArgumentException.class,
                 () -> service.newTask(name, tooLongDescription));
  }
  //test new taskname null
  @Test
  void newTaskNameNullTest() {
    // Arrange: service instance
    TaskService service = new TaskService();
    // Assert: null name is invalid
    assertThrows(IllegalArgumentException.class, () -> service.newTask(null));
  }
  //tests fpr mew task description to see if null
  @Test
  void newTaskDescriptionNullTest() {
    // Arrange: service instance
    TaskService service = new TaskService();
    // Assert: null description is invalid
    assertThrows(IllegalArgumentException.class,
                 () -> service.newTask(name, null));
  }
  
  @Test
  void deleteTaskTest() throws Exception {
    // Arrange: create service and add one task
    TaskService service = new TaskService();
    service.newTask();
    assertEquals(1, service.getTaskList().size());
    // Act: delete the created task
    service.deleteTask(service.getTaskList().get(0).getTaskId());
    // Assert: list is empty after deletion
    assertEquals(0, service.getTaskList().size());
  }
  //tests for delete task test not being found
  @Test
  void deleteTaskNotFoundTest() throws Exception {
    // Arrange: create service and add one task
    TaskService service = new TaskService();
    service.newTask();
    assertEquals(1, service.getTaskList().size());
    // Assert: attempting to delete a non-existent id throws exception and leaves list unchanged
    assertThrows(Exception.class, () -> service.deleteTask(id));
    assertEquals(1, service.getTaskList().size());
  }
  //test for updated name
  @Test
  void updateNameTest() throws Exception {
    // Arrange: service with one task
    TaskService service = new TaskService();
    service.newTask();
    // Act: update the name of the first task
    service.updateName(service.getTaskList().get(0).getTaskId(), name);
    // Assert: name updated
    assertEquals(name, service.getTaskList().get(0).getName());
  }
  //test for updated description
  @Test
  void updateDescriptionTest() throws Exception {
    // Arrange: service with one task
    TaskService service = new TaskService();
    service.newTask();
    // Act: update description
    service.updateDescription(service.getTaskList().get(0).getTaskId(),
                              description);
    // Assert: description updated
    assertEquals(description, service.getTaskList().get(0).getDescription());
  }
  //test for updated name
  @Test
  void updateNameNotFoundTest() throws Exception {
    // Arrange: service with one task
    TaskService service = new TaskService();
    service.newTask();
    // Assert: updating a non-existent id throws
    assertThrows(Exception.class, () -> service.updateName(id, name));
  }
  	//test for updated description
  @Test
  void updateDescriptionNotFoundTest() throws Exception {
    // Arrange: service with one task
    TaskService service = new TaskService();
    service.newTask();
    // Assert: updating description for missing id throws
    assertThrows(Exception.class,
                 () -> service.updateDescription(id, description));
  }

  @RepeatedTest(4)
  void UuidTest() {
    // Arrange: create service and add three tasks
    TaskService service = new TaskService();
    service.newTask();
    service.newTask();
    service.newTask();
    // Assert: three distinct ids exist and list size is correct
    assertEquals(3, service.getTaskList().size());
    assertNotEquals(service.getTaskList().get(0).getTaskId(),
                    service.getTaskList().get(1).getTaskId());
    assertNotEquals(service.getTaskList().get(0).getTaskId(),
                    service.getTaskList().get(2).getTaskId());
    assertNotEquals(service.getTaskList().get(1).getTaskId(),
                    service.getTaskList().get(2).getTaskId());
  }
}
