/**
 * Test package for ProjectOne. Contains unit tests that exercise service
 * and domain behaviors. Tests run under JUnit 5 and are executed by Maven
 * Surefire during the test phase.
 */
package projectOneTests;
