//*********************************************************
// Name: Cheyenne Anderson
//CS:499 Project One Enhancement 
//Date: 9/19/2026
//Original: CS 320 Project One
//*********************************************************
package projectOneTests;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import Main.Task;
//create class tasktest
class TaskTest {

  private String id, name, description;
  private String tooLongId, tooLongName, tooLongDescription;

  @BeforeEach
  void setUp() {
    // Initialize reusable fixture values so individual tests concisely focus on a single behavior.
    id = "1234567890";
    name = "This is Twenty Chars";
    description = "The task object shall have a required description.";
    tooLongId = "111222333444555666777888999";
    tooLongName = "This is way too long to be a task name";
    tooLongDescription =
        "The task object shall have a required description String field that cannot be longer than 50 characters. The description field shall not be null.";
  }
//test to get task id
  @Test
  void getTaskIdTest() {
    // Arrange: create a task with a specific ID
    Task task = new Task(id);
    // Assert: the task ID matches the expected value
    Assertions.assertEquals(id, task.getTaskId());
  }
//test to get task name
  @Test
  void getNameTest() {
    // Arrange: create a task with a specific name  
    Task task = new Task(id, name);
    // Assert: the task name matches the expected value
    Assertions.assertEquals(name, task.getName());
  }
//test to get task description
  @Test
  void getDescriptionTest() {
    // Arrange: create a task with a specific description
    Task task = new Task(id, name, description);
    // Assert: the task description matches the expected value
    Assertions.assertEquals(description, task.getDescription());
  }
//test to set new name
  @Test
  void setNameTest() {
    // Arrange: create a task with a specific name
    Task task = new Task(id, name);
    // Assert: the task name matches the expected value 
    Assertions.assertEquals(name, task.getName());
  }
//test to set new description
  @Test
  void setDescriptionTest() {
    // Arrange: create a task with a specific description
    Task task = new Task(id, name, description);
    // Assert: the task description matches the expected value
    Assertions.assertEquals(description, task.getDescription());
  }
//test for task ID to be too long
  @Test
  void TaskIdTooLongTest() {
    // Assert: creating a task with a too long ID should throw IllegalArgumentException
    Assertions.assertThrows(IllegalArgumentException.class,
                            () -> new Task(tooLongId));
  }
//test for task 
  @Test
  void setTooLongNameTest() {
    // Assert: creating a task with a too long name should throw IllegalArgumentException
    Assertions.assertThrows(IllegalArgumentException.class,
                            () -> new Task(id, tooLongName));
  }
//Test for description to be too long
  @Test
  void setTooLongDescriptionTest() {
    // Assert: creating a task with a too long description should throw IllegalArgumentException
    Assertions.assertThrows(IllegalArgumentException.class,
                            () -> new Task(id, name, tooLongDescription));
  }
//tests to see if task ID null to throw exception
  @Test
  void TaskIdNullTest() {
    // Assert: creating a task with a null ID should throw IllegalArgumentException
    Assertions.assertThrows(IllegalArgumentException.class,
                            () -> new Task(null));
  }
//test if task name is null and throw exception
  @Test
  void TaskNameNullTest() {
    // Assert: creating a task with a null name should throw IllegalArgumentException
    Assertions.assertThrows(IllegalArgumentException.class,
                            () -> new Task(id, null));
  }
//test if description is null and throw exception
  @Test
  void TaskDescriptionNullTest() {
    // Assert: creating a task with a null description should throw IllegalArgumentException
    Assertions.assertThrows(IllegalArgumentException.class,
                            () -> new Task(id, name, null));
  }
}
