//*********************************************************
// Name: Cheyenne Anderson
//CS:499 Project One Enhancement 
//Date: 9/19/2026
//Original: CS 320 Project One
//*********************************************************

package Main;

import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Service for creating, storing, updating, and removing appointments.
 * Appointments are stored in memory by appointment ID using a ConcurrentHashMap
 * The service validates date ranges and descriptions and prevents overlapping
 * appointment windows when adding or updating scheduled time ranges.
 */

public class AppointmentService {

	private final Map<String, Appointment> appointmentStore = new ConcurrentHashMap<>();

	//Returns the current number of appointments stored
	public int getAppointmentCount() {
		// Return the current number of stored appointments. 
		// This is an O(1) operation on ConcurrentHashMap.
		return appointmentStore.size();
	}

	//Returns a snapshot list of all stored appointments
	public List<Appointment> getAppointmentList() {
		// The returned list is a copy and is not backed by the internal map.
		// Provide a snapshot copy of the appointments to callers. Returning
		// the internal collection directly would allow external mutation.
		return new ArrayList<>(appointmentStore.values());
	}

	//Prints each appointment's ID, date, and description to standard output
	public void displayAppointmentList() {
		// Iterate over the current entries and print details.
		// used for manual inspection and test coverage 
		for (Appointment a : appointmentStore.values()) {
			System.out.println("\t Appointment ID: " + a.getAppointmentID());
			System.out.println("\t Appointment Date: " + a.getAppointmentDate());
			System.out.println("\t Appointment Description: " + a.getAppointmentDesc());
		}
	}

	//Adds a single-point appointment where start and end are the same instant
	//
	// @param appointmentDate start/end date for the appointment
	// @param appointmentDesc appointment description text
	//
	public void addAppointment(Date appointmentDate, String appointmentDesc) {
		// Create a single-point appointment via Builder which applies validation and defaults. 
		  //Put the created appointment into the
		  // concurrent map keyed by its generated id.
		Appointment appt = new Appointment.Builder()
			.setStartDate(appointmentDate)
			.setEndDate(appointmentDate)
			.setAppointmentDesc(appointmentDesc)
			.build();
		appointmentStore.put(appt.getAppointmentID(), appt);
	}

	//Adds a ranged appointment after validating input and checking conflicts.
	//Two appointments are considered overlapping when:
	 // existingStart < newEnd AND newStart < existingEnd.
	 // @param startDate appointment start date/time
	 // @param endDate appointment end date/time
	 // @param appointmentDesc appointment description text
	 // @throws IllegalArgumentException if validation fails or overlap is detected
	 //

	public void addAppointment(Date startDate, Date endDate, String appointmentDesc) {
		// validate via AppValidator
		AppValidator.validateAppointmentRange(startDate, endDate);
		AppValidator.validateAppointmentDesc(appointmentDesc);

		// To avoid race conditions where another thread inserts a conflicting
		// appointment between the overlap check and the put, perform the
		// overlap validation and insert while holding a lock on the map.
		synchronized (appointmentStore) {
			// check for overlap: two ranges [s1,e1) and [s2,e2) overlap if s1 < e2 && s2 < e1
			for (Appointment existing : appointmentStore.values()) {
				Date s1 = existing.getAppointmentDate();
				Date e1 = existing.getAppointmentEndDate();
				Date s2 = startDate;
				Date e2 = endDate;
				// check for overlap using the half open interval condition
				if (s1.before(e2) && s2.before(e1)) {
					throw new IllegalArgumentException("Appointment conflict: overlapping time range detected.");
				}
			}
			// create and store the new appointment
			Appointment appt = new Appointment.Builder()
				.setStartDate(startDate)
				.setEndDate(endDate)
				.setAppointmentDesc(appointmentDesc)
				.build();
			appointmentStore.put(appt.getAppointmentID(), appt);
		}
	}

	//Retrieves an appointment by ID.
	 // @param appointmentID appointment identifier
	 // @return matching appointment, or null when not found
	public Appointment getAppointment(String appointmentID) {
		return appointmentStore.get(appointmentID);
	}

	//Removes an appointment by ID.
	 // If the ID is not present, no action is taken.
	 // @param appointmentID appointment identifier to remove
	public void deleteAppointment(String appointmentID) {
		appointmentStore.remove(appointmentID);
	}

	//Updates an appointment's start date while preserving its original duration.
	 // The new date range is validated and checked for overlap against all other
	   // appointments before replacing the existing record.
	 // @param updatedDate new start date/time
	 // @param appointmentID appointment identifier to update
	 // @throws IllegalArgumentException if the updated range conflicts with another appointment
	public void updateAppointmentDate(Date updatedDate, String appointmentID) {
		Appointment existing = appointmentStore.get(appointmentID);
		if (existing == null) {
			System.out.println("Appointment ID: " + appointmentID + " not found.");
			return;
		}
		// build a new appointment with updated date range (keep same duration time)
		Date currentStart = existing.getAppointmentDate();
		Date currentEnd = existing.getAppointmentEndDate();
		long duration = currentEnd.getTime() - currentStart.getTime();
		Date newStart = updatedDate;
		Date newEnd = new Date(updatedDate.getTime() + Math.max(0, duration));

		// validate and check overlaps (excluding the existing appointment)
		AppValidator.validateAppointmentRange(newStart, newEnd);

		// Perform overlap checks and replacement to avoid races
		synchronized (appointmentStore) {
			for (Appointment other : appointmentStore.values()) {
				if (other.getAppointmentID().equals(appointmentID)) continue;
				if (other.getAppointmentDate().before(newEnd) && newStart.before(other.getAppointmentEndDate())) {
					throw new IllegalArgumentException("Appointment conflict when updating date.");
				}
			}
			// create a new appointment with the updated date range and same description
			Appointment updated = new Appointment.Builder()
				.setStartDate(newStart)
				.setEndDate(newEnd)
				.setAppointmentDesc(existing.getAppointmentDesc())
				.build();
			appointmentStore.put(appointmentID, updated);
		}
	}

	//Updates the description for an existing appointment.
	 // @param updatedString new description text
	 // @param appointmentID appointment identifier to update
	public void updateAppointmentDesc(String updatedString, String appointmentID) {
		Appointment existing = appointmentStore.get(appointmentID);
		if (existing == null) {
			System.out.println("Appointment ID: " + appointmentID + " not found.");
			return;
		}
		// validate the new description
		AppValidator.validateAppointmentDesc(updatedString);

		// Atomically replace the appointment description using computeIfPresent so
		// we don't lose updates when concurrent modifications occur.
		appointmentStore.computeIfPresent(appointmentID, (k, cur) ->
			new Appointment.Builder()
				.setStartDate(cur.getAppointmentDate())
				.setEndDate(cur.getAppointmentEndDate())
				.setAppointmentDesc(updatedString)
				.build()
		);
	}
}

