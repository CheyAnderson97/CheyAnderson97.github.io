//*********************************************************
// Name: Cheyenne Anderson
//CS:499 Project One Enhancement 
//Date: 9/19/2026
//Original: CS 320 Project One
//*********************************************************

package Main;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Thread-safe service for managing contacts in memory using key indexed lookups.
 */
public class ContactService {

    // ConcurrentHashMap replacing legacy List search loops for O(1) performance
    private final Map<String, Contact> contactStore = new ConcurrentHashMap<>();

    // ContactService performs validation on incoming data
        // before storing or updating. It exposes simple CRUD operations.

    public void addContact(Contact contact) {
        // Validate the Contact object using centralized rules before inserting.
        // This ensures callers cannot add invalid contacts.
        // AppValidator.validateContact throws IllegalArgumentException on failure.
        AppValidator.validateContact(contact);
        if (contactStore.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact ID already exists: " + contact.getContactId());
        }
        contactStore.put(contact.getContactId(), contact);
    }

    public void deleteContact(String contactId) {
        // Validate the provided id format, then attempt removal. 
        // If the id does not exist we surface an error so callers can detect failures.
        AppValidator.validateId(contactId);
        if (contactStore.remove(contactId) == null) {
            throw new IllegalArgumentException("Contact ID not found for deletion: " + contactId);
        }
    }

    public void updateFirstName(String contactId, String newFirstName) {
        // Load the existing record and validate the new first name.
        // We then create a new Contact instance and replace the old entry atomically in the map.
        Contact existing = getContact(contactId);
        AppValidator.validateFirstName(newFirstName);
        // Create a new Contact instance with the updated first name while preserving other fields.
        Contact updated = new Contact.Builder()
                .setContactId(existing.getContactId())
                .setFirstName(newFirstName)
                .setLastName(existing.getLastName())
                .setPhone(existing.getPhone())
                .setAddress(existing.getAddress())
                .build();

        contactStore.put(contactId, updated);
    }
    // The update methods above follow a pattern: retrieve the existing contact, validate the new value
    public void updateLastName(String contactId, String newLastName) {
        Contact existing = getContact(contactId);
        AppValidator.validateLastName(newLastName);
        // Create a new Contact instance with the updated last name while preserving other fields.
        Contact updated = new Contact.Builder()
                .setContactId(existing.getContactId())
                .setFirstName(existing.getFirstName())
                .setLastName(newLastName)
                .setPhone(existing.getPhone())
                .setAddress(existing.getAddress())
                .build();

        contactStore.put(contactId, updated);
    }
    // The updatePhone and updateAddress methods follow the same pattern as above, ensuring immutability and validation.
    public void updatePhone(String contactId, String newPhone) {
        // Validate new phone number format and create a replacement Contact
        // preserving other fields.
        Contact existing = getContact(contactId);
        AppValidator.validatePhone(newPhone);
        // Create a new Contact instance with the updated phone while preserving other fields.
        Contact updated = new Contact.Builder()
                .setContactId(existing.getContactId())
                .setFirstName(existing.getFirstName())
                .setLastName(existing.getLastName())
                .setPhone(newPhone)
                .setAddress(existing.getAddress())
                .build();

        contactStore.put(contactId, updated);
    }
    // The updateAddress method follows the same pattern as above, ensuring immutability and validation.
    public void updateAddress(String contactId, String newAddress) {
        Contact existing = getContact(contactId);
        AppValidator.validateAddress(newAddress);
        // Create a new Contact instance with the updated address while preserving other fields.
        Contact updated = new Contact.Builder()
                .setContactId(existing.getContactId())
                .setFirstName(existing.getFirstName())
                .setLastName(existing.getLastName())
                .setPhone(existing.getPhone())
                .setAddress(newAddress)
                .build();

        contactStore.put(contactId, updated);
    }
    // The getContact method retrieves a contact by ID, validating the ID format and throwing an exception if not found.
    public Contact getContact(String contactId) {
        AppValidator.validateId(contactId);
        Contact contact = contactStore.get(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found: " + contactId);
        }
        return contact;
    }
    // The getContactCount method returns the current number of contacts stored for testing and monitoring.
    public int getContactCount() {
        return contactStore.size();
    }
}