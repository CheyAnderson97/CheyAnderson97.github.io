//*********************************************************
// Name: Cheyenne Anderson
//CS:499 Project One Enhancement 
//Date: 9/19/2026
//Original: CS 320 Project One
//*********************************************************

package Main;

import java.util.Date;
import java.util.Calendar;

/**
 * Centralized validation utility for appointments, tasks, and contacts.
 * This single class holds symbolic constants and small validation helpers so
 * business rules live in one place and are easy to update.
 */

public final class AppValidator {

	// Appointment rules
	public static final int MAX_APPOINTMENT_DESC = 50;


	// Task rules
	public static final int MAX_TASK_NAME = 20;
	public static final int MAX_TASK_DESC = 50;
	public static final int MAX_ID_LENGTH = 10;

	private AppValidator() {}

	// This class is intentionally final and contains only static helpers.
	// It centralizes validation rules so all services and entities enforce
	   // the same constraints without duplicating logic.

	/**
	 * Validate a start/end appointment range.
	 * start must not be null
	 * end must not be before start (end == start allowed)
	 * start must not be in the past
	 */

	public static void validateAppointmentRange(Date start, Date end) {
		// Start and end must be non null. Nulls indicate programming errors.
		if (start == null) {
			throw new IllegalArgumentException("Start date cannot be null");
		}
		if (end == null) {
			throw new IllegalArgumentException("End date cannot be null");
		}
		// End must not be before start (equal is allowed for instant events)
		if (end.before(start)) {
			throw new IllegalArgumentException("End date must be after start date");
		}
		// Prevent scheduling in the past relative to the current system time.
		Date now = new Date();
		if (start.before(now)) {
			throw new IllegalArgumentException("Appointment start cannot be in the past");
		}
	}

	/**
	 * Validate a short appointment description not empty and within the limit.
	 */
	public static void validateAppointmentDesc(String desc) {
		if (desc == null || desc.isBlank() || desc.length() > MAX_APPOINTMENT_DESC) {
			throw new IllegalArgumentException("Appointment description must be present and <= " + MAX_APPOINTMENT_DESC);
		}
	}

	// Task validation helpers
	public static void validateTaskId(String id) {
		if (id == null || id.isBlank() || id.length() > MAX_ID_LENGTH) {
			throw new IllegalArgumentException("Task ID must not be null/blank and must be <= " + MAX_ID_LENGTH + " characters.");
		}
	}
	// Task name and description validation
	public static void validateTaskName(String name) {
		if (name == null || name.isBlank() || name.length() > MAX_TASK_NAME) {
			throw new IllegalArgumentException("Task name must not be null/blank and must be <= " + MAX_TASK_NAME + " characters.");
		}
	}
	//	Task description validation
	public static void validateTaskDescription(String desc) {
		if (desc == null || desc.isBlank() || desc.length() > MAX_TASK_DESC) {
			throw new IllegalArgumentException("Task description must not be null/blank and must be <= " + MAX_TASK_DESC + " characters.");
		}
	}
	//*********************************************************
	// Contact-specific rules 
	//*********************************************************

	// Contact validation helpers
	public static final int MAX_CONTACT_ID_LENGTH = 10;
	public static final int MAX_FIRST_NAME_LENGTH = 10;
	public static final int MAX_LAST_NAME_LENGTH = 10;
	public static final int EXACT_PHONE_LENGTH = 10;
	public static final int MAX_ADDRESS_LENGTH = 30;

	// Contact validation methods
	public static void validateId(String id) {
		if (id == null || id.isBlank() || id.length() > MAX_CONTACT_ID_LENGTH) {
			throw new IllegalArgumentException("Contact ID must not be null/blank and must be <= " + MAX_CONTACT_ID_LENGTH + " characters.");
		}
	}
	// First name validation
	public static void validateFirstName(String firstName) {
		if (firstName == null || firstName.isBlank() || firstName.length() > MAX_FIRST_NAME_LENGTH) {
			throw new IllegalArgumentException("First name must not be null/blank and must be <= " + MAX_FIRST_NAME_LENGTH + " characters.");
		}
	}
	// Last name validation
	public static void validateLastName(String lastName) {
		if (lastName == null || lastName.isBlank() || lastName.length() > MAX_LAST_NAME_LENGTH) {
			throw new IllegalArgumentException("Last name must not be null/blank and must be <= " + MAX_LAST_NAME_LENGTH + " characters.");
		}
	}

	// Phone number validation
	public static void validatePhone(String phone) {
		if (phone == null || phone.length() != EXACT_PHONE_LENGTH || !phone.matches("\\d+")) {
			throw new IllegalArgumentException("Phone number must be exactly " + EXACT_PHONE_LENGTH + " digits.");
		}
	}

	// Address validation
	public static void validateAddress(String address) {
		if (address == null || address.isBlank() || address.length() > MAX_ADDRESS_LENGTH) {
			throw new IllegalArgumentException("Address must not be null/blank and must be <= " + MAX_ADDRESS_LENGTH + " characters.");
		}
	}
	// Validate an entire Contact object
	public static void validateContact(Contact contact) {
		if (contact == null) {
			throw new IllegalArgumentException("Contact object cannot be null.");
		}
		validateId(contact.getContactId());
		validateFirstName(contact.getFirstName());
		validateLastName(contact.getLastName());
		validatePhone(contact.getPhone());
		validateAddress(contact.getAddress());
	}
}

	// Validator notes:
	// - This class centralizes all basic rule checks used by entities and services. 
	//   Keeping validation in one place avoids duplication and ensures consistent behavior across the system.
	// - Methods here throw IllegalArgumentException for invalid inputs. 
	//   Callers should show these exceptions to indicate incorrect usage.