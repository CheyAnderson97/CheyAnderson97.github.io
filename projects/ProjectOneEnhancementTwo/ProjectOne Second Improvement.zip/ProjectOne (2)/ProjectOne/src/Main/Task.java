//*********************************************************
// Name: Cheyenne Anderson
//CS:499 Project One Enhancement 
//Date: 9/19/2026
//Original: CS 320 Project One
//*********************************************************

package Main;

 //Immutable Task with Builder pattern. 
 //Validation delegated to AppValidator.

public class Task {

  private String taskId;
  private String name;
  private String description;

  // Task represents a unit of work with a short name and longer description.
  // Validation rules in AppValidator so they are consistent project wide.

  public Task() {
	this.taskId = "INITIAL";
	this.name = "INITIAL";
	this.description = "INITIAL DESCRIPTION";
  }

  // Public constructors above provide simple, validated ways to create a Task.
  // They call AppValidator where appropriate to enforce id,name,and description
	// constraints so the Task object is always valid after construction.
  
	// Constructor with taskId only, validates input and sets default name and description
  public Task(String taskId) {
	AppValidator.validateTaskId(taskId);
	this.taskId = taskId;
	this.name = "INITIAL";
	this.description = "INITIAL DESCRIPTION";
  }

  // Constructor with taskId and name, validates inputs and sets default description
  public Task(String taskId, String name) {
	AppValidator.validateTaskId(taskId);
	AppValidator.validateTaskName(name == null ? "" : name);
	this.taskId = taskId;
	this.name = name;
	this.description = "INITIAL DESCRIPTION";
  }

  // Full constructor validates all fields and ensures the Task is always in a valid state.
  public Task(String taskId, String name, String desc) {
	AppValidator.validateTaskId(taskId);
	AppValidator.validateTaskName(name == null ? "" : name);
	AppValidator.validateTaskDescription(desc == null ? "" : desc);
	this.taskId = taskId;
	this.name = name;
	this.description = desc;
  }

	// Getters below provide read-only access to the Task fields. The class is immutable
  public final String getTaskId() { return taskId; }
  public final String getName() { return name; }
  public final String getDescription() { return description; }

	// Builder for an immutable creation 
  public static class Builder {
	private String taskId;
	private String name;
	private String description;

	public Builder() {}
	// Builder methods return the Builder instance for fluent chaining.
	public Builder setTaskId(String taskId) { this.taskId = taskId; return this; }
	public Builder setName(String name) { this.name = name; return this; }
	public Builder setDescription(String description) { this.description = description; return this; }

	// Build method validates and constructs a new Task instance.
	public Task build() {
	  if (this.taskId != null) AppValidator.validateTaskId(this.taskId);
	  AppValidator.validateTaskName(this.name == null ? "" : this.name);
	  AppValidator.validateTaskDescription(this.description == null ? "" : this.description);
	  Task t = new Task();
	  if (this.taskId != null) t.taskId = this.taskId;
	  if (this.name != null) t.name = this.name;
	  if (this.description != null) t.description = this.description;
	  return t;
	}
  }
}
