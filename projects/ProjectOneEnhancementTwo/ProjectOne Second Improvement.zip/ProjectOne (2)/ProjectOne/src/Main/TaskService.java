//*********************************************************
// Name: Cheyenne Anderson
//CS:499 Project One Enhancement 
//Date: 9/19/2026
//Original: CS 320 Project One
//*********************************************************

package Main;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class TaskService {
  private final Map<String, Task> taskStore = new ConcurrentHashMap<>();

  // TaskService manages Task entities in a thread-safe map. 
  //It exposes simple creation, deletion and update methods. 
    //getTaskList returns a snapshot list for compatibility with existing tests and callers.

  private String newUniqueId() {
    // Create a short unique id for tasks and truncating it.
    // keeps ids compact while remaining practically unique for tests.
    return UUID.randomUUID().toString().replace("-", "").substring(0, 10);
  }

  // search and throw if not found 
  private Task searchForTask(String id) throws Exception {
    // Lookup by id in the concurrent map. 
    //Throw a generic Exception to match existing tests which expect an Exception when the task is missing.
    Task t = taskStore.get(id);
    if (t == null) throw new Exception("The Task does not exist.");
    return t;
  }

  // creates new task 
  public void newTask() {
    Task task = new Task.Builder()
        .setTaskId(newUniqueId())
        .setName("INITIAL")
        .setDescription("INITIAL DESCRIPTION")
        .build();
    taskStore.put(task.getTaskId(), task);
  }

  public void newTask(String name) {
    // validate name in builder
    Task task = new Task.Builder()
        .setTaskId(newUniqueId())
        .setName(name)
        .setDescription("INITIAL DESCRIPTION")
        .build();
    taskStore.put(task.getTaskId(), task);
  }

  public void newTask(String name, String description) {
    Task task = new Task.Builder()
        .setTaskId(newUniqueId())
        .setName(name)
        .setDescription(description)
        .build();
    taskStore.put(task.getTaskId(), task);
  }

  // Note: newTask overloads validate their inputs via Task.Builder which
  // delegates to AppValidator. 
    //This keeps validation logic centralized
    // and makes the service methods simple wrappers around creation and store.

  // deletes task
  public void deleteTask(String id) throws Exception {
    Task t = searchForTask(id);
    taskStore.remove(t.getTaskId());
  }

  // updates task name (immutable : replace entry)
  public void updateName(String id, String name) throws Exception {
    Task existing = searchForTask(id);
    Task updated = new Task.Builder()
        .setTaskId(existing.getTaskId())
        .setName(name)
        .setDescription(existing.getDescription())
        .build();
    taskStore.put(id, updated);
  }

  public void updateDescription(String id, String description) throws Exception {
    Task existing = searchForTask(id);
    Task updated = new Task.Builder()
        .setTaskId(existing.getTaskId())
        .setName(existing.getName())
        .setDescription(description)
        .build();
    taskStore.put(id, updated);
  }

  // returns a snapshot list for tests
  public List<Task> getTaskList() { return new ArrayList<>(taskStore.values()); }

  // Design notes for TaskService:
  //~Uses immutable Task instances and replaces entries on update to avoid
  //   in place mutation problems in concurrent environments.
  //~Exceptions are used to signal missing tasks, callers and tests rely on
  //   these exceptions to detect error conditions.
  //~ID generation is simple and deterministic enough for tests
  //   while maintaining uniqueness across runs.
}
