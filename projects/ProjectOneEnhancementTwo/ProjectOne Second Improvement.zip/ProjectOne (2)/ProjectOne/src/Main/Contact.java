//*********************************************************
// Name: Cheyenne Anderson
//CS:499 Project One Enhancement 
//Date: 9/19/2026
//Original: CS 320 Project One
//*********************************************************

package Main;

/**
 * Immutable Contact entity built using the Builder Pattern.
 */
public final class Contact {

    private final String contactId;
    private final String firstName;
    private final String lastName;
    private final String phone;
    private final String address;

    private Contact(Builder builder) {
        this.contactId = builder.contactId;
        this.firstName = builder.firstName;
        this.lastName = builder.lastName;
        this.phone = builder.phone;
        this.address = builder.address;
        
        // Enforce validation upon object construction
        AppValidator.validateContact(this);
    }

    public String getContactId() {
        return contactId;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }
    // Simple getters above return the raw stored values. The class is immutable
    // so callers receive references but cannot modify the Contact state.

    // Static Builder Class used to create Contact instances in a self-documenting way.
    public static class Builder {
        private String contactId;
        private String firstName;
        private String lastName;
        private String phone;
        private String address;

        public Builder setContactId(String contactId) {
            this.contactId = contactId;
            return this;
        }

        public Builder setFirstName(String firstName) {
            this.firstName = firstName;
            return this;
        }

        public Builder setLastName(String lastName) {
            this.lastName = lastName;
            return this;
        }

        public Builder setPhone(String phone) {
            this.phone = phone;
            return this;
        }

        public Builder setAddress(String address) {
            this.address = address;
            return this;
        }

        public Contact build() {
            // Build and validate the Contact; AppValidator will throw for invalid fields.
            // The Contact constructor calls AppValidator.validateContact(this),
            // ensuring the returned Contact is valid. Builders make test setup
            // and object creation clearer and reduce constructor overloads.
            return new Contact(this);
        }
    }
}