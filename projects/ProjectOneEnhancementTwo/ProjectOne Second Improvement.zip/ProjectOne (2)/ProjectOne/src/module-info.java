//*********************************************************
// Name: Cheyenne Anderson
//CS:499 Project One Enhancement 
//Date: 9/19/2026
//Original: CS 320 Project One
//*********************************************************
/**
 * 
 */
module ProjectOne {
	// Export package so unit tests in a separate module can access classes.
	exports Main;
}
